
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default mainpanel">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
							<?php if(isset($_SESSION['account_type'])) {?>
									 
								 <?php if($_SESSION['account_type'] == "Reception"){?>
								 	<fieldset>
										<legend><p class="animated bounceInLeft"><strong>Welcome::</strong> <?php echo $_SESSION['account_name']?></p></legend>
											<img src="<?php echo WEB_ROOT; ?>/images/reception.jpg" style="width:100%;">
									</fieldset>	
									
									<?php }elseif($_SESSION['account_type'] == "Accountant"){ ?>
									<fieldset>
										<legend><p class="animated bounceInLeft"><strong>Welcome::</strong> <?php echo $_SESSION['account_name']?></p></legend>
											<img src="<?php echo WEB_ROOT; ?>/images/accountant.jpg" style="width:100%;">
									</fieldset>
									<?php }elseif($_SESSION['account_type'] == "Chairman"){ ?>
										<fieldset>
										<legend><p class="animated bounceInLeft"><strong>Welcome::</strong> <?php echo $_SESSION['account_name']?></p></legend>
											<!-- <img src="<?php //echo WEB_ROOT; ?>/images/accountant.jpg" style="width:100%;"> -->
											<h4>Super Administrator</h4>
									</fieldset>
									<?php }else{ ?>
									<fieldset>
										<legend><p class="animated bounceInLeft"><strong>Welcome::</strong> <?php echo $_SESSION['account_name']?></p></legend>
											<center><h2>Welcome to our resturant</h2></center>
									</fieldset>	
									<?php } ?>
									
									<?php }else{ ?>

									<fieldset class="animated fadeInUp">
										<legend><h2 class="text-left">WELCOME TO COMMAND GUEST HOUSE</h2></legend>
											<p>We Provide our guests a unique experience, through which they connect with the best, 
												and to offer top quality service to our entire guest and provided comfort abundance.</p>
									</fieldset>	
									<?php } ?>
									<hr>


								</div>
							</div>
						</div>	

				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
