<ol class="breadcrumb">
  <li><a href="<?php echo WEB_ROOT; ?>index.php?page=smpoolbookinglist">Swimming Pool Booking</a></li>
  <li><a href="<?php echo WEB_ROOT; ?>index.php?page=hallbookinglist">Conference Hall Booking</a></li>
</ol>