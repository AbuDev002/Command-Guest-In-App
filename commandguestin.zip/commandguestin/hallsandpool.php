<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Reception"){?>
	<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default" style="margin-top:78px;">
				
						<div class="panel-body">	
							<div class="col-xs-12 col-sm-12">
								<?php include_once('bookingmenu.php');?>
								

							</div>
							<hr>
							<div class="row">
								<div class="col-md-4"></div>
								<div class="col-md-4">
									<a href="<?php echo WEB_ROOT; ?>index.php?page=makebooking" class="btn btn-default btn-block">Make Booking</a>
								</div>
								<div class="col-md-4"></div>
							</div>
						</div>
					</div>		
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>