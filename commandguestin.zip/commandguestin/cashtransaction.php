<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Accountant"){?>
	<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default" style="margin-top:78px;">
				
							<div class="panel-body">
								<div class="row">
									<div class="col-md-2"></div>
									<div class="col-md-8">
										<br>
										<table class="table table-bordered">
											<tr>
												<td align="center" colspan="3"><strong>Transaction History From All Units</strong></td>
											</tr>
											<tr>
												<td><strong>Rooms Reservation Sales Balance:</strong></td>
												<td>&#8358;
													<?php
													//rooms reservation sales balance 
														include_once('includes/dbconnect.php');
														$getbalacne = mysqli_query($conn,'select current_ubalance from tbl_units where id=1');
														$rreservebalance = mysqli_fetch_array($getbalacne);
														
														echo number_format($rreservebalance['current_ubalance'], 2, '.', ',');
													?>
												</td>
											</tr>
										<tr>
											<td><strong>Revenue Center Sales Balance</strong></td>
											<td>&#8358;
												<?php 
												//revenue sales balance
													include_once('includes/dbconnect.php');
													$poolbalance = mysqli_query($conn,'select current_ubalance from tbl_units where id=3');
													$oreservebalance = mysqli_fetch_array($poolbalance);
													echo number_format($oreservebalance['current_ubalance'], 2, '.', ',');
												?>
											</td>
										</tr>
										<tr>
											<td><strong>Resturant Sales Balance</strong></td>
											<td>&#8358;
												<?php 
													//resturant sales balance
													include_once('includes/dbconnect.php');
													$buyfoodbalance = mysqli_query($conn,'select current_ubalance from tbl_units where id=2');
													$foodreservebalance = mysqli_fetch_array($buyfoodbalance);
													echo number_format($foodreservebalance['current_ubalance'], 2, '.', ',');
												?>
											</td>
										</tr>
										<tr>
											<td><strong>Total Account Balance</strong></td>
											<td>&#8358;
												<?php 
												  $overalbalance = $rreservebalance['current_ubalance'] + $oreservebalance['current_ubalance'] + $foodreservebalance['current_ubalance'];
												   echo number_format($overalbalance, 2, '.', ',');
												?>
											</td>
										</tr>
										</table>
									</div>
									<div class="col-md-2"></div>
								</div>	

								<div class="row">
									<div class="col-md-2"></div>
									<div class="col-md-8" style="border:1px solid silver;box-shadow: 2px 3px 2px 3px #846E86;">
										<h4>Cash Deposit and Withdrawal</h4>
										<?php
											include_once('includes/dbconnect.php');
											if($_SERVER['REQUEST_METHOD'] =='POST'){
												$processby = $_SESSION['account_name'];
												$unitname = $_POST['unitname'];
												$transaction_type = $_POST['transaction_type'];
												$acctbalance = $_POST['acctbalance'];
												$transactionamt = $_POST['transactionamt'];
												$purpose = $_POST['purpose'];
												$newbalance = $_POST['newbalance'];


												$unitname = mysqli_real_escape_string($conn,$unitname);
												$transaction_type = mysqli_real_escape_string($conn,$transaction_type);
												$acctbalance = mysqli_real_escape_string($conn,$acctbalance);
												$transactionamt = mysqli_real_escape_string($conn,$transactionamt);
												$purpose = mysqli_real_escape_string($conn,$purpose);
												$newbalance = mysqli_real_escape_string($conn,$newbalance);

												if(empty($unitname) || empty($transaction_type) || empty($transactionamt) || empty($purpose)){
													echo "<p class='alert alert-danger'>Please enter all fields!</p>";
												}else{
													$addnewtrns_sql ="INSERT INTO cash_transactions (nameofunit,transaction_type,prev_balance,transaction_amount,purpose,remainingtotal,processedby)  VALUES('".$unitname."','".$transaction_type."','".$acctbalance."','".$transactionamt."','".$purpose."','".$newbalance."','".$processby."')";
													$addnewtrns_qry = mysqli_query($conn,$addnewtrns_sql);
													if($addnewtrns_qry){
														$updateunitbalances = mysqli_query($conn,"update tbl_units set current_ubalance='".$newbalance."' where id=".$unitname."");
														echo "<p class='alert alert-success'>Transaction was successful!</p>";
													}else{
														echo "<p class='alert alert-danger'>Unable to add food!</p>";
													}
												}
											}
											?>
										<form action="" method="post">
											<div class="form-group">
												<label>Name of Unit</label>
											<select class="form-control" name="unitname" id="unitname">
												<option>--Select Unit--</option>
												<?php 
													include_once('includes/dbconnect.php');
													$query = mysqli_query($conn,"select * from tbl_units");
													while($rows = mysqli_fetch_assoc($query)){
												?>
												<option value="<?php echo $rows['id']?>"><?php echo $rows['unit_name'];?></option>
											<?php } ?>
											</select>
											</div>
											<div class="form-group">
												<label>Type of Transaction</label>
												<select name="transaction_type" id="transaction_type" class="form-control">
													<option>--Select Transaction Type--</option>
													<option value="Withdrawal">Withdrawal</option>
													<option value="Deposit">Deposit</option>
												</select>
											</div>
							
											<div class="form-group" style="display:none;" id="accomodation_unit">
												<label>Accomodation Unit Account Balance</label>
											<input type="number" class="form-control" placeholder="Enter amount to withdraw..." name="acctbalance" id="accomodation_balance" class="acctbalance" value="<?php echo $rreservebalance['current_ubalance'];?>" readonly="readonly">
											</div>
											<div class="form-group" style="display:none;" id="revenue_center">
												<label>Revenue Center Account Balance</label>
											<input type="number" class="form-control" placeholder="Enter amount to withdraw..." name="acctbalance" id="revenue_balance" class="acctbalance" value="<?php echo $oreservebalance['current_ubalance'];?>" readonly="readonly">
											</div>
											<div class="form-group" style="display:none;" id="resturant_unit">
												<label>Resturant Unit Account Balance</label>
											<input type="number" class="form-control" placeholder="Enter amount to withdraw..." name="acctbalance" id="resturant_balance" class="acctbalance" value="<?php echo $foodreservebalance['current_ubalance'];?>" readonly="readonly">
											</div>
											<div class="form-group">
												<label>Amount</label>
											<input type="number" class="form-control" id="transactionamt" class="transactionamt" placeholder="Enter amount to withdraw..." name="transactionamt">
											</div>
											
											
											<div class="form-group">
												<label>Purpose of Transaction</label>
											<input type="text" class="form-control"  placeholder="Purpose of transaction..." name="purpose">
											</div>

											<div class="form-group">
												<label>New Account Balance:</label>
											<input type="text" class="form-control"  placeholder="" id="answer" name="newbalance" readonly="readonly">
											</div>
											<strong></strong>
											
											<div class="form-group">
												<button class="btn btn-default btn-block" name="btnTransaction">Process Transaction</button>
											</div>
										</form>
										
										<hr>
										
									</div>
									<div class="col-md-2"></div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>