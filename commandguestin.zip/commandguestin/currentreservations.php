<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Reception"){?>
	<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default" style="margin-top:78px;">
				
							<div class="panel-body">
							<ol class="breadcrumb">
							  <li><a href="index.php?page=manageroom">List of Rooms</a></li>
							  <li><a href="index.php?page=checkincheckout">Book Room</a></li>
							  
							</ol>	
								<div class="col-xs-12 col-sm-12">
									<table class="table table-bordered guest_record">
										<thead>
										<tr>
											<th>Room Name</th>
											<th>Guest Name</th>
											<th>Arival Date</th>
											<th>Date of Departure</th>
											<th>Amount Payed</th>
											<th>Room Status</th>
											<th>Action</th>
										</tr>
										</thead>
										<tbody>
										<?php
											$i =0; 
											$currentdate = date('Y-m-d');
											include_once('includes/dbconnect.php');
											$roomlist = mysqli_query($conn,"select * from reservation where status='Booked'");
											while($rlist = mysqli_fetch_array($roomlist)){
											$i++;
										  ?>
											<tr>
												<td>
													<?php 
														$query =mysqli_query($conn,"select * from room where roomNo = ".$rlist['roomNo']."");
														   $roomname = mysqli_fetch_array($query);
														   echo $roomname['roomName'];
													?>
													<a href="index.php?page=editreservation&rvid=<?php echo $rlist['reservation_id'];?>" title="Edit Reservation"><i class="glyphicon glyphicon-edit"></i></a>	
												</td>
												<td>
													<?php 
														$queryg =mysqli_query($conn,"select * from guest where guest_id = ".$rlist['guest_id']."");
														   $guestname = mysqli_fetch_array($queryg);
														   echo $guestname['firstname']." ".$guestname['lastname'];
													?>
												</td>
												<td><?php echo $rlist['arrival'];?></td>
												<td>
													<?php 
														if($currentdate > $rlist['departure']){
															echo "<span class='alert-danger'>".$rlist['departure']." Expired</span>";
														}else{
															echo $rlist['departure'];
														}
														
													?>
														
												</td>
												<td>&#8358; <?php echo number_format($rlist['payable'], 2, '.', ',');?></td>
												<td><?php echo $rlist['status'];?></td>
												<td><a href="index.php?page=checkout&reserveid=<?php echo $rlist['reservation_id'];?>" onclick="return confirm('Are you sure to checkout now?');"><span class="glyphicon glyphicon-checkout"></span>Checkout</a></td>
											</tr>
									   <?php } ?>
									   </tbody>
									</table>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>