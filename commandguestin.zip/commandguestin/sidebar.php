<?php
if(isset($_POST['login'])){
	$email = $_POST['log_email'];
	$password  = $_POST['log_pword'];
	$pass = sha1($password);
	
	 if ($email == '' OR $pass == '') {

         	message("Invalid Username and Password!", "error");
			redirect("index.php");
         
    } else {
		//$guest = new Guest();
		//$res = $guest->guest_login($email, $pass);
		$res = mysqli_query($conn,"select * from useraccounts where ACCOUNT_USERNAME='".$email."' and ACCOUNT_PASSWORD ='".$pass."'");

		if($count = mysqli_num_rows($res) == 1){
			$found_user = mysqli_fetch_array($res);
			$_SESSION['account_id']	= $found_user['ACCOUNT_ID'];
			$_SESSION['account_name']	= $found_user['ACCOUNT_NAME'];
			$_SESSION['username']	= $found_user['ACCOUNT_USERNAME'];
			$_SESSION['account_type']	= $found_user['ACCOUNT_TYPE'];
			redirect("index.php");
		}else{

			message("Username or Password Not Registered! Contact Your administrator.","error");
			redirect("index.php");
		}
	}

}
?>

<!--Side bar-->
	<div class="row">
		<div class="col-md-4 sidebar" id="sidebar" role="navigation">
		
				
					
			<?php if(!isset($_SESSION['account_type'])){?>
				<div class="panel panel-default menu-main" style="border-color: #846E86;">
				  <div class="panel-heading" style="background: #846E86;opacity: 0.5;color: #000;">Managers Login</div>
					   <div class="panel-body">	
						   <form  method="POST" action="#.php">
								<div class="col-xs-12 col-sm-12">

					            	<div class="form-group">
					            		<div class="row">
					            			<div class="col-xs-12 col-sm-12">
						              			<input type="email" placeholder="Email" class="form-control" name="log_email">
						              		</div>
						            	</div>
						            </div>
						            <div class="form-group">
						            	<div class="row">
					            			<div class="col-xs-12 col-sm-12">
						              			<input type="password" placeholder="Password" class="form-control" name="log_pword">
						              		</div>
						            	</div>
						            </div>

						            <div class="form-group">
						            	<div class="row">
					            			<div class="col-xs-12 col-sm-12">
						           				 <button type="submit" class="btn btn-default btn-block" align="right" name="login">Sign in</button>
						           			 </div>
						            	</div>
						            </div>
						        </div>
					        </form>
					       
						</div>
					</div>
					<?php }else{ ?>
					
					<?php if($_SESSION['account_type'] == "Reception") {?>
					<div class="small-menu-reception">
						<form>
							<select name="URL" onchange="window.location.href=this.form.URL.options[this.form.URL.selectedIndex].value" class="form-control">
								<option value="#">Main Menu</option>
								<option value="index.php?page=manageguest">Manage Guest</option>
								<option value="index.php?page=managerooms">Manage Rooms</option>
								<option value="index.php?page=checkbalances">Check Balances</option>
								<option value="index.php?page=trackbills">Track Bills</option>
								<option value="index.php?page=checkincheckout">Check-in & Checkout</option>
								<option value="index.php?page=hallsandpool">Revenue Center</option>
								<option value="index.php?page=changepassword">Change Password</option>
								<option value="logout.php">Logout</option>
							</select>
						</form>
					</div>
					<div class="panel panel-default menu-reception" style="border-color: #846E86;">	
					<div class="panel-heading" style="text-align:center;font-size:22px;font-weight: bold;">Main Menu</div>
					   <div class="panel-body">	
							<div class="col-xs-12 col-sm-12">
							 <ul class="list-group">
							 	<li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=manageguest" class="btn btn-default btn-block">Manage Guest</a></li>
							  <li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=managerooms" class="btn btn-default btn-block">Manage Rooms</a></li>
							  <li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=reservations" class="btn btn-default btn-block">Reservations</a></li>
							  <li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=checkbalances" class="btn btn-default btn-block">Check Balances</a></li>
							  <li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=trackbills" class="btn btn-default btn-block">Track Bills</a></li>
							  <li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=checkincheckout" class="btn btn-default btn-block">Checkin & Checkout</a></li>
							  <li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=hallsandpool" class="btn btn-default btn-block">Revenue Center</a></li>

							   <li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=changepassword" class="btn btn-default btn-block">Change Password</a></li>

							  <li class="list-group-item"> <a href="logout.php" class="btn btn-default btn-block"><span class="glyphicon glyphicon-log-out"></span> Logout </a></li>
							</ul>
							 
							</div>					            					            		
						</div>
					</div>
					<?php }elseif($_SESSION['account_type'] == "Accountant"){ ?>
					<div class="small-menu-accountant">
						<form>
							<select name="URL" onchange="window.location.href=this.form.URL.options[this.form.URL.selectedIndex].value" class="form-control">
								<option value="#">Main Menu</option>
								<option value="<?php echo WEB_ROOT; ?>index.php?page=checkbalancesaccount">Check Balances</option>
								<option value="<?php echo WEB_ROOT; ?>index.php?page=cashtransaction">Cash Transaction</option>
								
								<option value="<?php echo WEB_ROOT; ?>index.php?page=cashflow">Track Cash Flow</option>
								<option value="index.php?page=changepassword">Change Password</option>
								<option value="logout.php">Logout</option>
							</select>
						</form>
					</div>
					<div class="panel panel-default menu-accountant" style="border-color: #846E86;">
						<div class="panel-heading" style="text-align:center;font-size:22px;font-weight: bold;">Main Menu</div>
					   <div class="panel-body">	
							<div class="col-xs-12 col-sm-12">
							 <ul class="list-group">
							 	<li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=checkbalancesaccount" class="btn btn-default btn-block">Check Balances</a></li>
							  <li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=cashtransaction" class="btn btn-default btn-block">Cash Transaction</a></li>
							  <li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=cashflow" class="btn btn-default btn-block">Track Cash Flow</a></li>
							  <li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=changepassword" class="btn btn-default btn-block">Change Password</a></li>
							  <li class="list-group-item"> <a href="logout.php" class="btn btn-default btn-block"><span class="glyphicon glyphicon-log-out"></span> Logout </a></li>
							</ul>
							 
							</div>					            					            		
						</div>
					</div>
					<?php }elseif($_SESSION['account_type'] == "Chairman"){ ?>
					<div class="small-menu-accountant">
						<form>
							<select name="URL" onchange="window.location.href=this.form.URL.options[this.form.URL.selectedIndex].value" class="form-control">
								<option value="#">Main Menu</option>
								<option value="<?php echo WEB_ROOT; ?>index.php?page=checkbalancesaccount">Check Balances</option>
								<!-- <option value="<?php //echo WEB_ROOT; ?>index.php?page=cashtransaction">Cash Transaction</option> -->
								
								<option value="<?php echo WEB_ROOT; ?>index.php?page=cashflow">Track Cash Flow</option>
								<option value="<?php echo WEB_ROOT; ?>index.php?page=unitsummary">Balance Summary of Units</option>
								<option value="index.php?page=changepassword">Change Password</option>
								<option value="logout.php">Logout</option>
							</select>
						</form>
					</div>
					<div class="panel panel-default menu-accountant" style="border-color: #846E86;">
						<div class="panel-heading" style="text-align:center;font-size:22px;font-weight: bold;">Main Menu</div>
					   <div class="panel-body">	
							<div class="col-xs-12 col-sm-12">
							 <ul class="list-group">
							 	<li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=checkbalancesaccount" class="btn btn-default btn-block">Check Balances</a></li>
							
							  <li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=cashflow" class="btn btn-default btn-block">Track Cash Flow</a></li>
							   <li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=unitsummary" class="btn btn-default btn-block">Balance Summary of Units</a></li>

							   <li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=changepassword" class="btn btn-default btn-block">Change Password</a></li>

							  <li class="list-group-item"> <a href="logout.php" class="btn btn-default btn-block"><span class="glyphicon glyphicon-log-out"></span> Logout </a></li>
							</ul>
							 
							</div>					            					            		
						</div>
					</div>
					<?php }else{ ?>
						<div class="small-menu-accountant">
						<form>
							<select name="URL" onchange="window.location.href=this.form.URL.options[this.form.URL.selectedIndex].value" class="form-control">
								<option value="#">Main Menu</option>
								<option value="<?php echo WEB_ROOT; ?>index.php?page=managefood">Food</option>
								<option value="<?php echo WEB_ROOT; ?>index.php?page=buyfood">Buy Food</option>
								<option value="index.php?page=changepassword">Change Password</option>
								<option value="logout.php">Logout</option>
							</select>
						</form>
					</div>
					<div class="panel panel-default menu-accountant" style="border-color: #846E86;">
						<div class="panel-heading" style="text-align:center;font-size:22px;font-weight: bold;">Main Menu</div>
					   <div class="panel-body">	
							<div class="col-xs-12 col-sm-12">
							 <ul class="list-group">
							 	<li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=managefood" class="btn btn-default btn-block">Food</a></li>
							 	<li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=buyfood" class="btn btn-default btn-block">Buy Food</a></li>
							 	<li class="list-group-item"><a href="<?php echo WEB_ROOT; ?>index.php?page=changepassword" class="btn btn-default btn-block">Change Password</a></li>
							  <li class="list-group-item"> <a href="logout.php" class="btn btn-default btn-block"><span class="glyphicon glyphicon-log-out"></span> Logout </a></li>
							</ul>
							 
							</div>					            					            		
						</div>
					</div>
					<?php } } ?>

				 <!-- <form name="clock">      
					  <input  class="form-control" id="trans" type="label"  name="face" value="">
				</form> -->
			
			<!--/.well --> 
		</div>
		<!--/span-->
		<!--End of Side bar-->

