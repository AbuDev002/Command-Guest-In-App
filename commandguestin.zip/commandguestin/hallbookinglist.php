<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Reception"){?>
	<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default" style="margin-top:78px;">
				
						<div class="panel-body">	
							<div class="col-xs-12 col-sm-12">
								<?php include_once('bookingmenu.php');?>
							</div>
							<hr>
							<table class="table table-bordered table-responsive guest_record">
								<thead>
								<tr>
									<th colspan="5" align="center">Swimming Pool Booking List</th>
								</tr>
								<tr>
									<th>#</th>
									<th>Name of Booker</th>
									<th>Phone</th>
									<th>Purpose</th>
									<th>Check In Date</th>
									<th>Check Out Date</th>
									<th>Time of Event</th>
								</tr>
								</thead>
								<tbody>
								<?php 
									$i = 0;
									include_once('includes/dbconnect.php');
									$getpool = mysqli_query($conn,"select * from other_reservations where bookedfor='Conference Hall'");
									while($rows = mysqli_fetch_array($getpool)){
									 $i++;
									?>
									<tr>
										<td><?php echo $i;?></td>
										<td><?php echo $rows['guest_name'];?></td>
										<td><?php echo $rows['guest_phone'];?></td>
										<td><?php echo $rows['purpose'];?></td>
										<td><?php echo $rows['checkindate'];?></td>
										<td><?php echo $rows['checkoutdate'];?></td>
										<td><?php echo $rows['timeofevent'];?></td>
									</tr>
										
								<?php } ?>
								</tbody>
							</table>
						</div>
					</div>		
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>