<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Reception"){?>
	<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default" style="margin-top:78px;">
				
						<div class="panel-body">	
							<div class="col-xs-12 col-sm-12">
								<?php include_once('bookingmenu.php');?>
								

							</div>
							<hr>
							<div class="row">
								<div class="col-md-3"></div>
								<div class="col-md-6" style="border:1px solid silver;box-shadow: 2px 5px 2px 5px #846E86;">
									<?php
									include_once('includes/dbconnect.php');
									if($_SERVER['REQUEST_METHOD'] =='POST'){
										$guestname = $_POST['guestname'];
										$guestphone = $_POST['guestphone'];
										$guestbooking = $_POST['guestbooking'];
										$price = $_POST['price'];
										$purpose = $_POST['purpose'];
										$checkindate = $_POST['checkindate'];
										$checkoutdate = $_POST['checkoutdate'];
										$timeofevent = $_POST['timeofevent'];

										$guestname = mysqli_real_escape_string($conn,$guestname);
										$guestphone = mysqli_real_escape_string($conn,$guestphone);
										$guestbooking = mysqli_real_escape_string($conn,$guestbooking);
										$price = mysqli_real_escape_string($conn,$price);
										$purpose = mysqli_real_escape_string($conn,$purpose);
										$checkindate = mysqli_real_escape_string($conn,$checkindate);
										$checkoutdate = mysqli_real_escape_string($conn,$checkoutdate);
										$timeofevent = mysqli_real_escape_string($conn,$timeofevent);
										if(empty($guestname) || empty($guestphone) || empty($guestbooking)){
											echo "<p class='alert alert-danger'>Please enter all fields!</p>";
										}else{

										//select sum of revenue center
										$getrevenuebalance_qr = mysqli_query($conn,'select sum(amountpayed) as totalamnts from other_reservations');
										          $poolbalance_rs =  mysqli_fetch_array($getrevenuebalance_qr);
										          $poolbalance_total = $poolbalance_rs['totalamnts'] + $price;

											$addbooking_sql ="INSERT INTO other_reservations (guest_name,guest_phone,bookedfor,purpose,checkindate,checkoutdate,amountpayed,timeofevent)  VALUES('".$guestname."','".$guestphone."','".$guestbooking."','".$purpose."','".$checkindate."','".$checkoutdate."','".$price."','".$timeofevent."')";
											$addbooking_qry = mysqli_query($conn,$addbooking_sql);
											if($addbooking_qry){
												//update revenue center account balance
											   $updatepoolbalance = mysqli_query($conn,"UPDATE tbl_units SET current_ubalance='$poolbalance_total' WHERE id=3");
												echo "<p class='alert alert-success'>Booked Successfully!</p>";
											}else{
												echo "<p class='alert alert-danger'>Unable to Book!</p>";
											}
										}
									}
									?>
									<form action="" method="post">
										<div class="form-group">
											<label>Name:</label>
											<input type="text" class="form-control" name="guestname">
										</div>
										<div class="form-group">
											<label>Phone:</label>
											<input type="text" class="form-control" name="guestphone">
										</div>
										<div class="form-group">
											<label>Booking For:</label>
											<select class="form-control" name="guestbooking">
												<option value="">--Select--</option>
												<?php 
												include_once('includes/dbconnect.php');
												$query = mysqli_query($conn,"select * from amenities");
												while($rows = mysqli_fetch_assoc($query)){
													?>
													<option value="<?php echo $rows['amen_name']?>"><?php echo $rows['amen_name'];?></option>
												<?php } ?>
											</select>
										</div>
										 <div class="form-group">
					                      <label>Price:</label>
					                       <input type="text" class="form-control" autocomplete="off" name="price">
					                    </div>
										<div class="form-group">
											<label>purpose:</label>
											<textarea style="width:100%; height:200px;" name="purpose"></textarea>
										</div>
										<div class="form-group">
											<label>Checkin Date:</label>
											<input type="text" class="form-control from" name="checkindate" autocomplete="off"  data-date="" data-date-format="yyyy-mm-dd" data-link-field="any" data-link-format="yyyy-mm-dd">
										</div>
										<div class="form-group">
											<label>Checkout Date:</label>
											<input type="text" class="form-control to" name="checkoutdate" autocomplete="off"  data-date="" data-date-format="yyyy-mm-dd" data-link-field="any" data-link-format="yyyy-mm-dd">
										</div>
										 <div class="form-group">
					                      <label>Time:</label>
					                      <input type="text" class="form-control" autocomplete="off" name="timeofevent">
					                    </div>
										<div class="form-group">
											<button type="submit" class="btn btn-default btn-block">Book Now</button>
										</div>
									</form>
								</div>
								<div class="col-md-3"></div>
							</div>
						</div>
					</div>		
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>