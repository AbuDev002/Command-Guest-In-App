<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
						<div class="panel-body">	
					
							<fieldset>
								<legend><h2 class="text-left">Location</h2></legend>
									<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15699.664244804777!2d9.8389997!3d10.3485967!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb2d5a801f5ab55f!2sCommand%20Guest%20House%20Bauchi!5e0!3m2!1sen!2sng!4v1571990910746!5m2!1sen!2sng" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
									
									<br /><small>View <a href="#" style="color:#0000FF;text-align:left">My Saved Places</a> in a larger map</small>	
									<p><i>our strategic position gives an easy access to the northern tourist corridor circuit, 
									</i></p>

							</fieldset>	
						</div>
					</div>	
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
