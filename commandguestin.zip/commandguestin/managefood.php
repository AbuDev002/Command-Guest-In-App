<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Resturant"){?>
	<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default" style="margin-top:78px;">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="panel panel-default">
										<div class="panel-heading">
											<ol class="breadcrumb">
											<li><a href="index.php?page=managefood">List of Foods</a></li>
											  <li><a href="index.php?page=addfood">Add Food</a></li>
											</ol>
										</div>
										<div class="panel-body">
											<table class="table table-bordered guest_record">
												<thead>
												<tr>
													<td>#</td>
													<td>Food Name</td>
													<td>Food Type</td>
													<td>Food Price</td>
													<td>Action</td>
												</tr>
												</thead>
												<tbody>
												<?php 
													$n = 0;
													include_once('includes/dbconnect.php');
													$query = mysqli_query($conn,"select * from foods");
													while($foods = mysqli_fetch_array($query)){
													 $n = $n + 1;
												?>
												<tr>
													<td><?php echo $n;?></td>
													<td><?php echo  $foods['foodname'];?></td>
													<td><?php echo  $foods['foodtype'];?></td>
													<td>&#8358; <?php echo number_format($foods['foodprice'], 2, '.', ',');?></td>
													<td><a href="#"><span class="glyphicon glyphicon-trash"></span></a></td>
												</tr>

												<?php } ?>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>