<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Reception"){?>
	<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default" style="margin-top:78px;">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="panel panel-default">
										<div class="panel-heading">
											<ol class="breadcrumb">
											<li><a href="index.php?page=manageguest">List of Guest</a></li>
											  <li><a href="index.php?page=newguest">Add New Guest</a></li>
											</ol>
										</div>
										<div class="panel-body">
											<form action="" method="post">
												<div class="form-group">
													<label>Firstname</label>
												</div>
												<div class="form-group">
													<input type="text" name="firstname" class="form-control" placeholder="Enter firstname...">
												</div>

												<div class="form-group">
													<label>Surname</label>
												</div>

												<div class="form-group">
													
													<input type="text" name="surname" class="form-control" placeholder="Enter surname...">
												</div>

												<div class="form-group">
													<label>Othername</label>
												</div>

												<div class="form-group">
													
													<input type="text" name="othername" class="form-control" placeholder="Enter othername...">
												</div>
												<div class="form-group">
													<label>Address</label>
												</div>

												<div class="form-group">
													
													<textarea name="address" style="width:100%;" class="form-control"></textarea>
												</div>

												<div class="form-group">
													<label>City</label>
												</div>

												<div class="form-group">
													
													<input type="text" name="city" class="form-control" placeholder="Enter city...">
												</div>

												<div class="form-group">
													<label>Phone</label>
												</div>

												<div class="form-group">
													
													<input type="text" name="phone" class="form-control" placeholder="Enter phone...">
												</div>

												<div class="form-group">
													<label>E-mail</label>
												</div>

												<div class="form-group">
													<input type="text" name="email" class="form-control" placeholder="Enter email">
												</div>

												<div class="form-group">
													<label>Coming From</label>
												</div>

												<div class="form-group">
													<input type="text" name="comingfrom" class="form-control" placeholder="Coming from...">
												</div>
												
												<div class="form-group">
													<label>Next Destination</label>
												</div>

												<div class="form-group">
													<input type="text" name="nextdestination" class="form-control" placeholder="Next Destination...">
												</div>

												<div class="form-group">
													<label>Arival Date</label>
												</div>

												<div class="form-group">
													<input data-date="" data-date-format="yyyy-mm-dd" data-link-field="any" data-link-format="yyyy-mm-dd" type="text" name="arivaldate" class="form-control from" placeholder="Arival Date...">
												</div>

												<div class="form-group">
													<label>Departure Date</label>
												</div>

												<div class="form-group">
													<input data-date="" data-date-format="yyyy-mm-dd" data-link-field="any" data-link-format="yyyy-mm-dd" type="text" name="departdate" class="form-control to" placeholder="Departure Date...">
												</div>

												<div class="form-group">
													<button type="submit" class="btn btn-default btn-block">Add Geust</button>
												</div>
												
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>