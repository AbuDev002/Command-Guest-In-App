<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Resturant"){?>
	<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>
		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default" style="margin-top:78px;">
						<div class="panel-heading">
							<ol class="breadcrumb">
								<li><a href="index.php?page=managefood">List of Foods</a></li>
							    <li><a href="index.php?page=addfood">Add Food</a></li>
							</ol>
						</div>
							<div class="panel-body">	
								<div class="col-md-3"></div>
								<div class="col-md-6" style="border:1px solid silver;box-shadow: 2px 5px 2px 5px #846E86;">
									<?php
									include_once('includes/dbconnect.php');
									if($_SERVER['REQUEST_METHOD'] =='POST'){
										$foodname = $_POST['foodname'];
										$foodtype = $_POST['foodtype'];
										$foodprice = $_POST['foodprice'];
										$foodname = mysqli_real_escape_string($conn,$foodname);
										$foodtype = mysqli_real_escape_string($conn,$foodtype);
										$foodprice = mysqli_real_escape_string($conn,$foodprice);
										if(empty($foodname) || empty($foodtype) || empty($foodprice)){
											echo "<p class='alert alert-danger'>Please enter all fields!</p>";
										}else{
											$addfood_sql ="INSERT INTO foods (foodname,foodtype,foodprice)  VALUES('".$foodname."','".$foodtype."','".$foodprice."')";
											$addfood_qry = mysqli_query($conn,$addfood_sql);
											if($addfood_qry){
												echo "<p class='alert alert-success'>Food Added Successfully!</p>";
											}else{
												echo "<p class='alert alert-danger'>Unable to add food!</p>";
											}
										}
									}
									?>
									<form action="" method="post">	
										<label>Name of Food</label>
									<div class="form-group">
										<input type="text" class="form-control" name="foodname">
									</div>
									<label>Food Type</label>
									<div class="form-group">
										<select class="form-control" name="foodtype">
										<option value="">--Select--</option>
										<option value="Protien">Protien</option>
										<option value="Caborhydrate">Caborhydrate</option>
										<option value="Fat and Oil">Fat and Oil</option>
										<option value="Mineral">Mineral</option>
									</select>
									</div>
									<label>Food Price</label>
									<div class="form-group">
										<input type="text" class="form-control" name="foodprice">
									</div>
									<button type="submit" class="form-control">Add Food</button>
									</form>
								</div>
								<div class="col-md-3"></div>
									
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>