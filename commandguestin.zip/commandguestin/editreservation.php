<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Reception"){?>
	<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default" style="margin-top:78px;">
							<?php 
							if(isset($_GET['rvid'])){
								$rvid = $_GET['rvid'];
									
							}
							?>
							<div class="panel-body">
							<h3>Edit Reservation</h3>
							<?php
								include_once('includes/dbconnect.php');
								if($_SERVER['REQUEST_METHOD'] =='POST'){
									$roomname = mysqli_real_escape_string($conn,$_POST['roomname']);
									$guestname = mysqli_real_escape_string($conn,$_POST['guestname']);
									$arivaldate = mysqli_real_escape_string($conn,$_POST['arivaldate']);
									$departuredate = mysqli_real_escape_string($conn,$_POST['departuredate']);
									$amountpayed = mysqli_real_escape_string($conn,$_POST['amountpayed']);
									$roomstatus = mysqli_real_escape_string($conn,$_POST['roomstatus']);
									
									
									if($roomname =="" || $guestname =="" || $arivaldate =="" || $departuredate =="" || $amountpayed =="" || $roomstatus ==""){
										echo "<p class='alert alert-danger'>Please enter all reservation fields</p>";
										
									}else{
										$query = "UPDATE reservation 
												SET 
													roomNo =".$roomname.",
													guest_id  =".$guestname.",
													arrival   ='".$arivaldate."',
													departure  ='".$departuredate."',
													payable ='".$amountpayed."',
													status   ='".$roomstatus."'
													WHERE reservation_id =".$rvid."";
											$updated_row = mysqli_query($conn,$query);
										if ($updated_row) {
											echo "<p class='alert alert-success'>Reservation Updated Successfully.
										 </p>";
										}else {
											echo "<p class='alert alert-danger'>Reservation Not Updated !</p>";
										}
									}
								}
							?>	
								<div class="row">
									<div class="col-md-3"></div>
									<div class="col-md-6" style="border:1px solid silver;box-shadow: 2px 5px 2px 5px #846E86;">
										<?php
											include_once('includes/dbconnect.php');
									$rvsql = mysqli_query($conn,"select * from reservation where reservation_id= $rvid");
										$updaterv = mysqli_fetch_array($rvsql);
										?>
										<form action="" method="post">
										<div class="form-group">
											<label>Room Name</label>
											<select name="roomname" class="form-control">
												<?php 
												include_once('includes/dbconnect.php');
												$getroomid = mysqli_query($conn,"select roomName,roomNo from room where roomNo= ".$updaterv['roomNo']."");
													$droomname = mysqli_fetch_array($getroomid);
												?>
												<option value="<?php echo $droomname['roomNo'];?>"><?php echo $droomname['roomName'];?></option>
												<?php 
												include_once('includes/dbconnect.php');
												$getallrooms = mysqli_query($conn,"select * from room");
													while($allrooms = mysqli_fetch_array($getallrooms)){
												?>
												<option value="<?php echo $allrooms['roomNo'];?>"><?php echo $allrooms['roomName'];?></option>
												<?php } ?>
												
											</select>
										</div>
										<div class="form-group">
											<label>Name of Guest</label>
											<?php 
												include_once('includes/dbconnect.php');
												$getgestid = mysqli_query($conn,"select * from guest where guest_id= ".$updaterv['guest_id']."");
													$dguestname = mysqli_fetch_array($getgestid);
												?>
											<select name="guestname" class="form-control">
												<option value="<?php echo $dguestname['guest_id']; ?>"><?php echo $dguestname['firstname']." ".$dguestname['lastname'];?></option>
												<?php 
												include_once('includes/dbconnect.php');
												$getallguest = mysqli_query($conn,"select * from guest");
													while($allguests = mysqli_fetch_array($getallguest)){
												?>
												<option value="<?php echo $allguests['guest_id'];?>"><?php echo $allguests['firstname']." ".$allguests['lastname'];?></option>
												<?php } ?>
											</select>
										</div>
										<div class="form-group">
											<label>Arival Date</label>
											<input data-date="" data-date-format="yyyy-mm-dd" data-link-field="any" data-link-format="yyyy-mm-dd" type="text" name="arivaldate" value="<?php echo $updaterv['arrival'];?>" class="form-control from">
										</div>
										<div class="form-group">
											<label>Date of Departure</label>
											<input data-date="" data-date-format="yyyy-mm-dd" data-link-field="any" data-link-format="yyyy-mm-dd" type="text" name="departuredate" value="<?php echo $updaterv['departure'];?>" class="form-control to">
										</div>
										<div class="form-group">
											<label>Amount Payed</label>
											<input type="text" name="amountpayed" value="<?php echo $updaterv['payable'];?>" class="form-control">
										</div>
										<div class="form-group">
											<label>Room Status</label>
											<select name="roomstatus" class="form-control">
												<option><?php echo $updaterv['status'];?></option>
												<option value="Available">Available</option>
												<option value="Booked">Booked</option>
											</select>
										</div>
										<div class="form-group">
											<button type="submit" class="btn btn-default btn-block">Update Reservation</button>
										</div>
									</form>
									</div>
									<div class="col-md-3"></div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>