<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Accountant" || $_SESSION['account_type'] == "Chairman"){?>
	<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default" style="margin-top:78px;">
						<center><h4>Track Withdrawal and Deposit</h4></center>
							<div class="panel-body">	
								<div class="row">
									<div class="col-md-3"></div>
									<div class="col-md-6" style="border:1px solid silver;box-shadow: 2px 3px 2px 3px #846E86;padding-top:10px;">
										<div class="form-group">
											<form action="" method="post">
												<!-- <label>Select Unit</label> -->
											<select class="form-control" name="unit" onchange="if(this.value !=0){this.form.submit();}">
												<option>--Select Unit--</option>
												<?php 
													include_once('includes/dbconnect.php');
													$query = mysqli_query($conn,"select * from tbl_units");
													while($rows = mysqli_fetch_assoc($query)){
													if (@$_POST['unit'] == $rows['id']) {

														echo "<option value=\"".$rows['id']."\" selected='selected'>".$rows['unit_name']."</option>"; 
													} else {
														echo "<option value=\"".$rows['id']."\">".$rows['unit_name']."</option>";       
													}
												?>
												
											<?php } ?>
											</select>
											</form>
										</div>
									</div>
									<div class="col-md-3"></div>
									
								</div>
								<hr>
								<table class="table table-bordered table-responsive guest_record">
									<thead>
									<tr>
										<th>#</th>
										<th>Name of Unit</th>
										<th>Transaction Type</th>
										<th>Prev. Balance</th>
										<th>Amount</th>
										<th>Date</th>
										<th>Purpose</th>
										<th>Last Balance</th>
									</tr>
									</thead>
									<tbody>
									<?php 
									$i =0;
									if(isset($_POST['unit'])){
										$unitname = $_POST['unit'];
										include_once('includes/dbconnect.php');
										$gettransacton_sql = mysqli_query($conn,"select * from cash_transactions where nameofunit = '".$unitname."'");
										while($transaction_list = mysqli_fetch_array($gettransacton_sql)){
										$i++;
									?>
									<tr>
										<td><?php echo $i;?></td>
										<td>
											<?php 
												$query =mysqli_query($conn,"select * from tbl_units where id = ".$transaction_list['nameofunit']."");
												   $unitname = mysqli_fetch_array($query);
												   echo $unitname['unit_name'];
											?>		
										</td>
										<td><?php echo $transaction_list['transaction_type'];?></td>
										<td>&#8358; <?php echo number_format($transaction_list['prev_balance'], 2, '.', ',');?></td>
										<td>&#8358; <?php echo number_format($transaction_list['transaction_amount'], 2, '.', ',');?></td>
										<td><?php echo $transaction_list['dateoftransaction'];?></td>
										<td><?php echo $transaction_list['purpose'];?></td>
										<td>&#8358; <?php echo number_format($transaction_list['remainingtotal'], 2, '.', ',');?></td>
										
									</tr>

									<?php
											}
										}
									?>
									</tbody>
								</table>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>