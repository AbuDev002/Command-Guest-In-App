<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
</head>

<body>
<div class="container">
    <form action="" class="form-horizontal"  role="form">
        <fieldset>
            <legend>Bootstrap-DateTimePicker</legend>
            <div class="form-group">
                <label for="dtp_input1" class="col-md-2 control-label">Date And Time</label>
                <div class="input-group date form_datetime col-md-5" data-date="1979-09-16T05:25:07Z" data-date-format="dd MM yyyy - HH:ii p" data-link-field="dtp_input1">
                    <input class="form-control" size="16" type="text" value="" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
					<span class="input-group-addon"><span class="glyphicon glyphicon-th"></span></span>
                </div>
				<input type="hidden" id="dtp_input1" value="" /><br/>
            </div>
			<div class="form-group">
                <label for="dtp_input2" class="col-md-2 control-label">Date Only</label>
                <div class="input-group date form_date col-md-5" data-date="" data-date-format="dd MM yyyy" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">
                    <input class="form-control" size="16" type="text" value="" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
					<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                </div>
				<input type="hidden" id="dtp_input2" value="" /><br/>
            </div>
			<div class="form-group">
                <label for="dtp_input3" class="col-md-2 control-label">Time Only</label>
                <div class="input-group date form_time col-md-5" data-date="" data-date-format="hh:ii" data-link-field="dtp_input3" data-link-format="hh:ii">
                    <input class="form-control" size="16" type="text" value="" readonly>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
					<span class="input-group-addon"><span class="glyphicon glyphicon-time"></span></span>
                </div>
				<input type="hidden" id="dtp_input3" value="" /><br/>
            </div>
        </fieldset>
    </form>
</div><!---End Container-->

<script type="text/javascript" src="jquery/jquery-1.8.3.min.js" charset="UTF-8"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript" src="js/locales/bootstrap-datetimepicker.uk.js" charset="UTF-8"></script>

<script type="text/javascript">
//in this line of code, to display the datetimepicker,  we used ‘form_datetime’ as an argument to be 
//passed in javascript. This is for Date and Time.
    $('.form_datetime').datetimepicker({
        language:  'en',
        weekStart: 1,
        todayBtn:  1,
		autoclose: 1,
		todayHighlight: 1,
		startView: 2,
		forceParse: 0,
        showMeridian: 1
    });
//this is for Date only	
 	$('.form_date').datetimepicker({
        language:  'en',
        weekStart: 1,
        todayBtn:  1,
		autoclose: 1,
		todayHighlight: 1,
		startView: 2,
		minView: 2,
		forceParse: 0
    });
//this is for Time Only	
	$('.form_time').datetimepicker({
        language:  'en',
        weekStart: 1,
        todayBtn:  1,
		autoclose: 1,
		todayHighlight: 1,
		startView: 1,
		minView: 0,
		maxView: 1,
		forceParse: 0
    });
</script>

</body>
</html>



<H2>SITE MISSION AND OTHER STUFFS</H2>
<fieldset>
                                        <legend><h2 class="text-left">Our Mission</h2></legend>
                                            <p>We Provide our guests a unique experience, through which they connect with the best, 
                                                and to offer top quality service to our entire guest and provided comfort abundance.</p>
                                    </fieldset> 
                                    <fieldset>
                                        <legend><h2 class="text-left">Our Vision</h2></legend>
                                            <p>Command Guest House provides best quality of services applying top quality 
                                                guest house and conference facilities, in order to fulfill the best way in the relevant needs of every guest.</p>
                                    </fieldset>
                                    <fieldset>
                                        <legend><h2 class="text-left">About Us</h2></legend>
                                        
                                    On the year 2017, Command Guest House started. It is, located at Kano Road Bauchi, Bauchi State. It is well structured with 14 air conditioned rooms, Hot and Cold Shower, Cable Television and WIFI area.
                                    </fieldset>
                                    <br/><br/><br/><br/>

FEATURED ROOM FIELDSET
<br/><br/><br/><br/>
                                    <fieldset>
                                        <legend><h2 class="text-left">Featured Rooms</h2></legend>
                                        <?php 

                                        $mydb->setQuery("SELECT *,typeName FROM room ro, roomtype rt WHERE ro.typeID = rt.typeID");
                                        $cur = $mydb->loadResultList();

                                            foreach($cur as $room){
                                                $image = WEB_ROOT . 'admin/mod_room/'.$room->roomImage;
                                                echo '<div style=" float:left;  margin:7px;">';     
                                                echo '<a href="'.$image.'" rel="prettyPhoto[mwaura]"><img src="'.$image.'" width="100px" height="120px" 
                                                style="-webkit-border-radius:5px; -moz-border-radius:5px;"  title="'.$room->roomName.'" alt="'.$room->roomName.'" >
                                                <br>'.$room->roomName.'<br>'.$room->typeName.'</a>';
                                                echo'</div>';
                                                
                                            }


                                        ?>

                                    </fieldset>