<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Reception" || $_SESSION['account_type'] == "Accountant" || $_SESSION['account_type'] == "Chairman"){?>
	<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">

					<div class="panel panel-default" style="margin-top:78px;">
				
							<div class="panel-body">	
								<div class="row">
									<div class="col-md-3">
									
								</div>
								<div class="col-md-6" style="border:1px solid silver;box-shadow: 2px 5px 2px 5px #846E86;">
									<form action="" method="post">
										<div class="form-group">
										<label>Unit</label>
										<select class="form-control" name="unit">
											<option>--Select Unit--</option>
											<?php 
												@$from = $_POST['from'];	
												@$to = $_POST['to'];	
												@$unit = $_POST['unit'];	
												include_once('includes/dbconnect.php');
												$query = mysqli_query($conn,"select * from tbl_units");
												while($rows = mysqli_fetch_assoc($query)){
												  if($unit == $rows['id']) {

												echo "<option value=".$rows['id']." selected='selected'>".$rows['unit_name']."</option>"; 
											} else {
												echo "<option value=".$rows['id'].">".$rows['unit_name']."</option>";       
											}

											?>
											<!-- <option value="<?php //echo $rows['id']?>"><?php //echo $rows['unit_name'];?></option> -->
										<?php } ?>
										</select>
									</div>
									<div class="form-group">
										<label>From</label>
										<input type="text" class="form-control from" name="from" autocomplete="off" data-date="" data-date-format="yyyy-mm-dd" data-link-field="any" data-link-format="yyyy-mm-dd" value="<?php if(isset($from)){ echo $from;}?>">
									</div>
									<div class="form-group">
										<label>To</label>
										<input type="text" class="form-control to" name="to" autocomplete="off" data-date="" data-date-format="yyyy-mm-dd" data-link-field="any" data-link-format="yyyy-mm-dd" value="<?php if(isset($to)){ echo $to;}?>">
									</div>
									<div class="form-group">
										<button class="btn btn-default btn-block" name="btncheckbalances">Check Balance</button>
									</div>
									</form>
								</div>
								<div class="col-md-3"></div>
								<br>
								<table class="table table-bordered">
									<tr>
										<td></td>
									</tr>
								</table>
							</div>
							<?php
									//$reservedby = $_SESSION['account_name'];
									$tatalamount = 0;
									include_once('includes/dbconnect.php');
									if(isset($_POST['btncheckbalances'])){
									$from = mysqli_real_escape_string($conn,$_POST['from']);	
									$to = mysqli_real_escape_string($conn,$_POST['to']);	
									//$sql ="SELECT * FROM reservation WHERE arrival = '$from' AND  departure='$to'";
									$sql = "SELECT * FROM reservation WHERE ((
												'$from' >= arrival
												AND  '$from' <= departure
												)
												OR (
												'$to' >= arrival
												AND  '$to' <= departure
												)
												OR (
												arrival >=  '$from'
												AND arrival <=  '$to'
												)
												)";
									$post = mysqli_query($conn,$sql);
									if($post){
										while($result = mysqli_fetch_assoc($post)){
										$tatalamount = $tatalamount + $result['payable'];
								?>
								<table class="table table-bordered table-responsive" style="font-size:12px;">
									<tr>
										<td><b>Processed By:</b> <?php echo $result['reservedby']?></td>
										<td><b>Arrival:</b> <?php echo $result['arrival'];?></td>
										<td><b>Departure:</b> <?php echo $result['departure'];?></td>
										<td><b>Amount Payed: </b>&#8358; <?php echo number_format($result['payable'], 2, '.', ',');?></td>
										<!-- <td><a href="index.php?page=billlist&guestid=<?php //echo $result['guest_id'];?>">View Guest History</a></td> -->
									</tr>
								</table>
											
									<?php } } }else{ ?>
										<center><p>Your Search Query Not Found.</p></center>
									<?php } ?>
									<center><b>Total Amount Generated:</b> &#8358; <?php echo number_format($tatalamount, 2, '.', ',');?></center>
								</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>