-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2019 at 02:17 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `commandguestin`
--

-- --------------------------------------------------------

--
-- Table structure for table `amenities`
--

CREATE TABLE IF NOT EXISTS `amenities` (
  `amen_id` int(100) NOT NULL AUTO_INCREMENT,
  `amen_name` varchar(100) NOT NULL,
  `amen_desp` varchar(100) NOT NULL,
  `amen_image` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  PRIMARY KEY (`amen_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `amenities`
--

INSERT INTO `amenities` (`amen_id`, `amen_name`, `amen_desp`, `amen_image`, `price`) VALUES
(1, 'Swimming Pool', 'Pool for swimming and celebrations', '', ''),
(2, 'Conference Hall', 'Conference Hall', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `buyfood`
--

CREATE TABLE IF NOT EXISTS `buyfood` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guestname` varchar(100) NOT NULL,
  `guestid` int(11) NOT NULL DEFAULT '0',
  `foodname` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `foodbuydate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `soldby` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `buyfood`
--

INSERT INTO `buyfood` (`id`, `guestname`, `guestid`, `foodname`, `price`, `foodbuydate`, `soldby`) VALUES
(1, 'Shehu Adamu', 0, 'Rice', '400', '2019-12-15 07:42:24', 'Resturant'),
(2, 'Aliyu Musa', 0, 'Beand and plantain', '600', '2019-12-15 07:42:58', 'Resturant'),
(3, 'Shehu Adamu', 0, 'Danwake', '400', '2019-12-15 12:43:49', 'Resturant');

-- --------------------------------------------------------

--
-- Table structure for table `cash_transactions`
--

CREATE TABLE IF NOT EXISTS `cash_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount_withdraw` varchar(100) NOT NULL,
  `amount_deposite` varchar(100) NOT NULL,
  `dateoftransaction` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `purpose` text NOT NULL,
  `remainingtotal` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `comment_id` int(100) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `comment` varchar(100) NOT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `firstname`, `lastname`, `email`, `comment`) VALUES
(1, 'Abubakar', 'Ahmad', 'ahmaduabu@gmail.com', '               Swiming Pool'),
(2, 'Jamal', 'Khaleed', 'jamal@gmail.com', '                '),
(3, 'Abubakar', 'Ahmad', 'ahmaadbakar@yahoo.com', '                Swimming pool'),
(4, 'Abubakar', 'Ahmad', 'ahmaduabu@gmail.com', '                nothing'),
(5, 'Abubakar', 'Ahmad', 'ahmaadbakar@gmail.com', '                '),
(6, 'Abdullahi', 'Lamido', 'admin@yahoo.com', '                '),
(7, 'Aisha', 'Abdullahi', 'aisha@gmail.com', '                Swimming Pool');

-- --------------------------------------------------------

--
-- Table structure for table `foods`
--

CREATE TABLE IF NOT EXISTS `foods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `foodname` varchar(100) NOT NULL,
  `foodtype` varchar(100) NOT NULL,
  `foodprice` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `foods`
--

INSERT INTO `foods` (`id`, `foodname`, `foodtype`, `foodprice`) VALUES
(1, 'Rice', 'Caborhydrate', '250'),
(2, 'Beand and plantain', 'Protien', '400'),
(3, 'Danwake', 'Caborhydrate', '400');

-- --------------------------------------------------------

--
-- Table structure for table `guest`
--

CREATE TABLE IF NOT EXISTS `guest` (
  `guest_id` int(30) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `zip` varchar(30) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`guest_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `guest`
--

INSERT INTO `guest` (`guest_id`, `firstname`, `lastname`, `country`, `city`, `address`, `zip`, `phone`, `email`, `password`) VALUES
(1, 'Abubakar', 'Ahmad', 'Nigeria', 'Bauchi', 'Bauchi', '', '08032343030', 'ahmaduabu@gmail.com', '12345'),
(2, 'Abdullahi', 'Lamido', 'Nigeria', 'Gombe', 'Gomb', '', '08030800580', 'admin@yahoo.com', '12345'),
(3, 'Aisha', 'Abdullahi', 'Nigeria', 'Adamawa', 'Mubi', '', '09003949499', 'aisha@gmail.com', ''),
(4, 'Aliyu ', 'Hassan', '', 'Gombe', '', '', '08052525252', 'ali@gmail.com', ''),
(5, 'Adamu ', 'Aminu', 'Nigeria', 'Bauchi', '', '', '0803569874', 'adam@gmail.com', ''),
(6, 'Hassan', 'Musa', '', '', '', '', '09000000000', 'hm@gmail.com', ''),
(7, 'Adamu', 'Abdullahi', '', 'Bauchi', 'Bauchi', '', '07012121212', 'adamu@gmail.com', '');

-- --------------------------------------------------------

--
-- Table structure for table `other_reservations`
--

CREATE TABLE IF NOT EXISTS `other_reservations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_name` varchar(100) NOT NULL,
  `guest_phone` varchar(100) NOT NULL,
  `bookedfor` varchar(100) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `checkindate` varchar(100) NOT NULL,
  `checkoutdate` varchar(100) NOT NULL,
  `amountpayed` varchar(100) NOT NULL,
  `timeofevent` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `other_reservations`
--

INSERT INTO `other_reservations` (`id`, `guest_name`, `guest_phone`, `bookedfor`, `purpose`, `checkindate`, `checkoutdate`, `amountpayed`, `timeofevent`) VALUES
(1, 'Adamu Abdullahi', '07012121212', 'Conference Hall', 'Meeting', '2019-12-15', '2019-12-16', '10000', '4pm');

-- --------------------------------------------------------

--
-- Table structure for table `ozekimessagein`
--

CREATE TABLE IF NOT EXISTS `ozekimessagein` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(30) DEFAULT NULL,
  `receiver` varchar(30) DEFAULT '+254714812921',
  `msg` varchar(160) DEFAULT NULL,
  `senttime` varchar(100) DEFAULT NULL,
  `receivedtime` varchar(100) DEFAULT NULL,
  `operator` varchar(100) DEFAULT NULL,
  `msgtype` varchar(160) DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ozekimessageout`
--

CREATE TABLE IF NOT EXISTS `ozekimessageout` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(30) DEFAULT '+254714812921',
  `receiver` varchar(30) DEFAULT NULL,
  `msg` varchar(160) DEFAULT NULL,
  `senttime` varchar(100) DEFAULT NULL,
  `receivedtime` varchar(100) DEFAULT NULL,
  `reference` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'send',
  `msgtype` varchar(160) DEFAULT 'SMS:TEXT',
  `operator` varchar(100) DEFAULT 'Safaricom',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE IF NOT EXISTS `reservation` (
  `reservation_id` int(11) NOT NULL AUTO_INCREMENT,
  `roomNo` int(50) NOT NULL,
  `guest_id` int(11) NOT NULL,
  `arrival` varchar(30) NOT NULL,
  `departure` varchar(30) NOT NULL,
  `adults` int(11) NOT NULL,
  `child` int(11) NOT NULL,
  `payable` int(11) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'pending',
  `booked` date NOT NULL,
  `confirmation` varchar(20) NOT NULL,
  `reservedby` varchar(100) NOT NULL,
  PRIMARY KEY (`reservation_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`reservation_id`, `roomNo`, `guest_id`, `arrival`, `departure`, `adults`, `child`, `payable`, `status`, `booked`, `confirmation`, `reservedby`) VALUES
(1, 1, 7, '2019-12-15', '2019-12-16', 1, 0, 5000, 'pending', '0000-00-00', '', 'Abubakar Ahmad');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE IF NOT EXISTS `room` (
  `roomNo` int(50) NOT NULL AUTO_INCREMENT,
  `typeID` int(50) NOT NULL,
  `roomName` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `Adults` int(50) NOT NULL,
  `Children` int(10) NOT NULL,
  `roomImage` varchar(200) DEFAULT NULL,
  `roomstatus` varchar(100) NOT NULL,
  PRIMARY KEY (`roomNo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`roomNo`, `typeID`, `roomName`, `price`, `Adults`, `Children`, `roomImage`, `roomstatus`) VALUES
(1, 1, 'Room 1', '5000', 2, 1, 'rooms/room1.png', ''),
(2, 1, 'Room 2', '10000', 1, 1, 'rooms/room2.png', ''),
(3, 1, 'Room 3', '15000', 2, 2, 'rooms/room3.png', '');

-- --------------------------------------------------------

--
-- Table structure for table `roomtype`
--

CREATE TABLE IF NOT EXISTS `roomtype` (
  `typeID` int(50) NOT NULL AUTO_INCREMENT,
  `typename` varchar(50) NOT NULL,
  `Desp` text NOT NULL,
  PRIMARY KEY (`typeID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `roomtype`
--

INSERT INTO `roomtype` (`typeID`, `typename`, `Desp`) VALUES
(1, 'Executive ', 'For Executives and VIPs'),
(4, 'Double', 'This type of room is for normal guest');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_units`
--

CREATE TABLE IF NOT EXISTS `tbl_units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(100) NOT NULL,
  `unit_balance` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_units`
--

INSERT INTO `tbl_units` (`id`, `unit_name`, `unit_balance`) VALUES
(1, 'Accomodation', '0.00'),
(2, 'Resturant', '0.00'),
(3, 'Revenue Center', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `useraccounts`
--

CREATE TABLE IF NOT EXISTS `useraccounts` (
  `ACCOUNT_ID` int(11) NOT NULL AUTO_INCREMENT,
  `ACCOUNT_NAME` varchar(255) NOT NULL,
  `ACCOUNT_USERNAME` varchar(255) NOT NULL,
  `ACCOUNT_PASSWORD` text NOT NULL,
  `ACCOUNT_TYPE` varchar(30) NOT NULL,
  PRIMARY KEY (`ACCOUNT_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `useraccounts`
--

INSERT INTO `useraccounts` (`ACCOUNT_ID`, `ACCOUNT_NAME`, `ACCOUNT_USERNAME`, `ACCOUNT_PASSWORD`, `ACCOUNT_TYPE`) VALUES
(3, 'Administrator', 'admin@yahoo.com', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 'Administrator'),
(4, 'Abubakar Ahmad', 'reception@yahoo.com', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 'Reception'),
(5, 'Accountant', 'accountant@yahoo.com', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 'Accountant'),
(6, 'Resturant', 'chef@gmail.com', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 'Resturant');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
