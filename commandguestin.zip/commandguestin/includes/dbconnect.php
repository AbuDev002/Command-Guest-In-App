<?php
	//mysql_connect('localhost','root','');
	//mysql_select_db('stdidcard');
	$conn=mysqli_connect("localhost","root","","commandguestin");
		if(mysqli_connect_errno($conn)){
			echo "Connection Failed:".mysqli_connect_error($conn);
			exit;
		}
?>