<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Reception"){?>
	<!--End of Header-->
<?php
$arrival= '';
$departure= '';
if (isset($_SESSION['from'])){
$arrival = $_SESSION['from']; 
$departure = $_SESSION['to'];
}
if(isset($_POST['btnbook'])){

	if (!isset($_SESSION['from']) || !isset($_SESSION['to'])){
		message("Please Choose check in Date and Check out Out date to continue reservation!", "error");
		redirect("index.php?page=checkincheckout");
	}
		 if(isset($_POST['roomid'])){
    	 $_SESSION['roomid']=$_POST['roomid'];
    	 redirect(WEB_ROOT. 'booking/');
   
	}
}
 /*if(!isset($_POST['adults'])){
    message("Choose from Adults!", "error");	
    redirect(".WEB_ROOT. 'booking/");
   	//exit;
 }*/
 /* if(isset($_POST['adults'])&&isset($_POST['child'])){
    $_SESSION['roomid']=$_POST['roomid'];
	$_SESSION['adults'] = $_POST['adults'];
	$_SESSION['child']  = $_POST['child'];
   */
//	$_SESSION['roomid']=$_POST['roomid'];

    //exit;
   //} 
  //}

?>
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default" style="margin-top:78px;">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
			<div class="panel panel-default" style="border:1px solid silver;box-shadow: 2px 5px 2px 5px #846E86;">
		   
			 <div class="panel-heading">Rooms Reservation</div>
			  <div class="panel-body">	
						   <form  method="POST" action="#.php">
								<div class="col-xs-12 col-sm-12">

					            	<div class="form-group">
					            		<div class="row">
					            			<div class="col-xs-12 col-sm-12">
					            				<label class="control-label" for="from">Check In</label>
							                    <input class="form-control from" autocomplete="off" size="11"  data-date="" data-date-format="yyyy-mm-dd" data-link-field="any" data-link-format="yyyy-mm-dd" type="text" name="from" id="from" value="<?php if(isset($arrival)){ echo $arrival;}?>">
							                   
						              		</div>
						            	</div>
						            </div>
						            <div class="form-group">
						            	<div class="row">
					            			<div class="col-xs-12 col-sm-12">
					            				<label class="control-label" for="to">Check Out</label>
						              			
								                    <input class="form-control to" autocomplete="off" size="11" type="text" name="to" id="to" value="<?php if(isset($departure)){ echo $departure;}?>" data-date="" data-date-format="yyyy-mm-dd" data-link-field="any" data-link-format="yyyy-mm-dd">
								                   
						              		</div>
						            	</div>
						            </div>

						            <div class="form-group">
						            	<div class="row">
					            			<div class="col-xs-12 col-sm-12">
						           				 <button type="submit" class="btn btn-default" align="right"name="avail">Check Availability</button>
						           			 </div>
						            	</div>
						            </div>
						        </div>
					        </form>
						</div>
			
		</div>
		<!-- <--the result> -->

				<div class="panel panel-default" style="border:1px solid silver;box-shadow: 2px 5px 2px 5px #846E86;">
						<div class="panel-body">	
							<fieldset>
								<p class="bg-warning">
							
									<?php 
									echo '<div class="alert alert-info" ><strong>From:'.$arrival. ' To: ' .$departure.'</strong>  </div>';
									?></p>
					

								<legend><h4 class="text-left">Room and Rates</h4></legend>
								
								<?php 
				  		$mydb->setQuery("SELECT *,typeName FROM room ro, roomtype rt WHERE ro.typeID = rt.typeID");
				  		$cur = $mydb->loadResultList();

				  			
						foreach ($cur as $result) {
							$mydb->setQuery("SELECT status FROM reservation
												WHERE ((
												'$arrival' >= arrival
												AND  '$arrival' <= departure
												)
												OR (
												'$departure' >= arrival
												AND  '$departure' <= departure
												)
												OR (
												arrival >=  '$arrival'
												AND arrival <=  '$departure'
												)
												)
												AND roomNo =".$result->roomNo);

				  			$stats = $mydb->executeQuery();
				  			$rows = mysqli_fetch_assoc($stats);

							$image = WEB_ROOT . 'admin/mod_room/'.$result->roomImage;
						echo '<div style="float:left; width:200px; margin-left:10px;">';
							echo '<div style="float:left; width:70px; margin-bottom:10px;">';				
					  			echo '<img src="'.$image .'" width="180px" height="150px" style="-webkit-border-radius:5px; -moz-border-radius:5px;"title="'.$result->roomName.'"/>';
							echo '</div>';	
				
						echo '<div style="float:right; height:125px; width:180px; margin:0px; color:#000033;">';
						echo '<form name="book"  method="POST" action="'.WEB_ROOT.'index.php?page=checkincheckout">';
						//'. $result->typeName.'<br/>'. $result->price.'<br/>'. $result->Adults.'<br/>
						echo '<input type="hidden" name="roomid" value="'.$result->roomNo.'"/>';
				  		echo '<p><strong>Room Type: '.$result->typeName.'<br/> 
		  						<strong>Max Adults: '.$result->Adults.',<br/>  Max Children: '.$result->Children.'<br/>
		  						<strong>Rate per Night: </strong> &#8358;'. $result->price.' </p>';
		
	            			$status=$rows['status'];
							if($status=='Booked'){
							  	echo '<div style="margin-top:10px; color: rgba(0,0,0,1); font-size:16px;"><strong>Room has been booked!</strong></div><br>';
							}elseif($status=='Uncleaned'){
								echo '<div style="margin-top:10px; color: rgba(0,0,0,1); font-size:16px;"><strong>Room is not cleaned!</strong></div><br>';
							}else{
								echo '
								  	 <div class="form-group">
							            	<div class="row">
						            			<div class="col-xs-12 col-sm-12">
						            				<input type="submit" class="btn btn-primary btn-sm" name="btnbook" onclick="return validateBook();" value="Book Now!"/>
																           				     
							           			 </div>
							            	</div>
							            </div>';
							}
	            			
            			
				  		 echo '</form>';
				  		echo '</div>';
						echo '</div>';
				  	
					  	}
					   
					  	?>

				  	
								
							</fieldset>	
						</div>
						<hr>

					</div>	


		<!-- the end of the result -->	
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>