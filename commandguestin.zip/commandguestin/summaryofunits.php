<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Chairman"){?>
	<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default" style="margin-top:78px;">
				
							<div class="panel-body">
								<div class="row">
									<div class="col-md-2"></div>
									<div class="col-md-8">
										<br>
										<table class="table table-bordered">
											<tr>
												<td align="center" colspan="3"><strong>Summary of Account From All Units</strong></td>
											</tr>
											<tr>
												<td><strong>Rooms Reservation Sales Balance:</strong></td>
												<td>&#8358;
													<?php
													//rooms reservation sales balance 
														include_once('includes/dbconnect.php');
														$getbalacne = mysqli_query($conn,'select current_ubalance from tbl_units where id=1');
														$rreservebalance = mysqli_fetch_array($getbalacne);
														
														echo number_format($rreservebalance['current_ubalance'], 2, '.', ',');
													?>
												</td>
											</tr>
										<tr>
											<td><strong>Revenue Center Sales Balance</strong></td>
											<td>&#8358;
												<?php 
												//revenue sales balance
													include_once('includes/dbconnect.php');
													$poolbalance = mysqli_query($conn,'select current_ubalance from tbl_units where id=3');
													$oreservebalance = mysqli_fetch_array($poolbalance);
													echo number_format($oreservebalance['current_ubalance'], 2, '.', ',');
												?>
											</td>
										</tr>
										<tr>
											<td><strong>Resturant Sales Balance</strong></td>
											<td>&#8358;
												<?php 
													//resturant sales balance
													include_once('includes/dbconnect.php');
													$buyfoodbalance = mysqli_query($conn,'select current_ubalance from tbl_units where id=2');
													$foodreservebalance = mysqli_fetch_array($buyfoodbalance);
													echo number_format($foodreservebalance['current_ubalance'], 2, '.', ',');
												?>
											</td>
										</tr>
										<tr>
											<td align="right"><strong>Total Account Balance</strong></td>
											<td>&#8358;
												<?php 
												  $overalbalance = $rreservebalance['current_ubalance'] + $oreservebalance['current_ubalance'] + $foodreservebalance['current_ubalance'];
												   echo number_format($overalbalance, 2, '.', ',');
												?>
											</td>
										</tr>
										</table>
										<hr>
										
									</div>
									<div class="col-md-2"></div>
								</div>	
								<table class="table table-bordered table-responsive guest_record">
											<thead>
												<tr>
													<th colspan="6" align="center">Record of Discounts Given</th>
												</tr>
												<tr>
													<th>Name of Guest</th>
													<th>Initial Amount</th>
													<th>Amount Recieved</th>
													<th>Discount Amount</th>
													<th>Date of Transaction</th>
													<th>Room</th>
													<th>Processed By</th>
												</tr>
											</thead>
											<tbody>
												<?php
													
													include_once('includes/dbconnect.php');
													$getalldiscounts = mysqli_query($conn,'select * from tbl_discounts');
													while($discountresult = mysqli_fetch_array($getalldiscounts)){
														$accualamount = $discountresult['amountrecieved'] + $discountresult['discountamount'];
												?>
													<tr>
														<td><?php echo $discountresult['guest_name'];?></td>
														<td>&#8358; <?php echo number_format($accualamount, 2, '.', ',');?></td>
														<td>&#8358; <?php echo number_format($discountresult['amountrecieved'], 2, '.', ',');?></td>
														<td>&#8358; <?php echo number_format($discountresult['discountamount'], 2, '.', ',');?></td>
														<td><?php echo $discountresult['dateoftransaction'];?></td>
														<td>
															<?php 
																$query =mysqli_query($conn,"select * from room where roomNo = ".$discountresult['room']."");
																   $roomname = mysqli_fetch_array($query);
																   echo $roomname['roomName'];
															?>
														</td>
														<td><?php echo $discountresult['processedby'];?></td>
														
													</tr>
												<?php } ?>
											</tbody>
										</table>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>