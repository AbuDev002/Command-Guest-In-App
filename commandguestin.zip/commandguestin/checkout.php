<?php
	include_once('includes/dbconnect.php');
	if(isset($_GET['reserveid'])){
		$reserveid = $_GET['reserveid'];
		$query = mysqli_query($conn,"update reservation set status ='Available' where reservation_id=".$reserveid."");
		header('location:index.php?page=reservations');
	}
?>