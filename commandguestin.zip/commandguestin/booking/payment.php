<?php

$arival    = $_SESSION['from']; 
$departure = $_SESSION['to'];
$name      = $_SESSION['name']; 
$last      = $_SESSION['last'];
$country   = $_SESSION['country'];
$city      = $_SESSION['city'] ;
$address   = $_SESSION['address'];
$zip       = $_SESSION['zip'] ;
$phone     = $_SESSION['phone'];
$guesttype     = $_SESSION['guesttype'];
$paymenttype     = $_SESSION['paymenttype'];
$company_name     = $_SESSION['company_name'];
$email     = $_SESSION['email'];
//$password  = $_SESSION['pass'];
$roomid   = $_SESSION['roomid'];
$_SESSION['Booked'] = 'Booked';
$stat     = $_SESSION['Booked'];
$days     = dateDiff($arival,$departure);

if(isset($_POST['btnsubmitbooking'])){
  $message = $_POST['message'];
function createRandomPassword() {

    $chars = "abcdefghijkmnopqrstuvwxyz023456789";

    srand((double)microtime()*1000000);

    $i = 0;

    $pass = '' ;
    while ($i <= 7) {

        $num = rand() % 33;

        $tmp = substr($chars, $num, 1);

        $pass = $pass . $tmp;

        $i++;

    }

    return $pass;

}
  //$confirmation = createRandomPassword();
  @$reservedby = $_SESSION['account_name'];
  @$guestfullname = $name.' '.$last;
  // @$guestname = $_POST['guestname'];
  // @$gpaymenttype = $_POST['paymenttype'];
  @$gcompany_name = $_POST['company_name'];
  @$purpose = $_POST['purpose'];
  @$amountpayed = $_POST['price'];
  @$timeofevent = $_POST['timeofevent'];
  @$guestbooking = $_POST['guestbooking'];
  @$checkindate = $_POST['checkindate'];
  @$checkoutdate = $_POST['checkoutdate'];
  @$special_request = $_POST['special_request'];
  @$givediscount = $_POST['givediscount'];
  @$percent = $_POST['percent'];
  @$total_discount = $_POST['total_discount'];
  //$_SESSION['confirmation'] = $confirmation;
  $mydb->setQuery("SELECT * FROM room where roomNo={$roomid}");
  $rmprice = $mydb->executeQuery();
  while($row = mysqli_fetch_assoc($rmprice)){
    $rate = $row['price']; 
  }  

  if($givediscount == 1){
      $payable= ($rate*$days) - $total_discount;
      $_SESSION['pay']= $payable;
  }else{
     $payable= $rate*$days;
      $_SESSION['pay']= $payable;
  }

//rooms reservation sales balance
$mydb->setQuery('select sum(payable) as rrtotal from reservation');
          $rreservebalance_run =  $mydb->executeQuery();
          $rreservebalance_rs =  $mydb->fetch_array($rreservebalance_run);
          $rreservebalance_total = $rreservebalance_rs['rrtotal'] + $payable;

//select sum of revenue center
$mydb->setQuery('select sum(amountpayed) as totalamnts from other_reservations');
          $poolbalance_run =  $mydb->executeQuery();
          $poolbalance_rs =  $mydb->fetch_array($poolbalance_run);
          $poolbalance_total = $poolbalance_rs['totalamnts'] + $amountpayed;

  //check guest
  $mydb->setQuery("SELECT * 
                FROM  guest 
                WHERE  `phone` ='{$phone}' OR email='{$email}'");
  $cur = $mydb->executeQuery();
  $row_count = $mydb->num_rows($cur);
  if ($row_count >=1 ) {

    $rows = $mydb->fetch_array($cur);
    $lastguest= $rows['guest_id'];

    $mydb->setQuery("UPDATE guest SET firstname='$name',lastname='$last',
                          country='$country',city='$city',address='$address',
                          zip='$zip',phone='$phone',email='$email' 
                      WHERE guest_id='$lastguest'");
    $res = $mydb->executeQuery();

  }else{

    $mydb->setQuery("INSERT INTO guest (firstname,lastname,country,city,address,zip,phone,email)
      VALUES ('$name','$last','$country','$city','$address','$zip','$phone','$email')");
    $res = $mydb->executeQuery();
    $lastguest=mysqli_insert_id($conn); 
   
   } 
  $mydb->setQuery("INSERT INTO reservation (roomNo,guest_id,arrival,departure,adults,child,payable,payment_type,company_name,status,reservedby,guesttype)
          VALUES ('$roomid','$lastguest','$arival','$departure','1','0','$payable','$paymenttype','$company_name','$stat','$reservedby','$guesttype')");
  $res = $mydb->executeQuery();
  $lastreserv=mysqli_insert_id($conn); 

  //update reservation sales account balance
   $mydb->setQuery("UPDATE tbl_units SET current_ubalance='$rreservebalance_total' WHERE id=1");
    $res = $mydb->executeQuery();

  if($special_request == 1){
  $mydb->setQuery("INSERT INTO `other_reservations` (`guest_name`, `guest_phone`, `bookedfor`, `purpose`, `checkindate`, `checkoutdate`,`amountpayed`,`timeofevent`) VALUES('$guestfullname','$phone','$guestbooking','$purpose','$checkindate','$checkoutdate','$amountpayed','$timeofevent')");
  $msg = $mydb->executeQuery();

  //update revenue center account balance
   $mydb->setQuery("UPDATE tbl_units SET current_ubalance='$poolbalance_total' WHERE id=3");
    $res = $mydb->executeQuery();
}

if($givediscount == 1){
  $mydb->setQuery("INSERT INTO `tbl_discounts` (`guest_name`, `amountrecieved`, `discountamount`, `room`, `processedby`) VALUES('$guestfullname','$payable','$total_discount','$roomid','$reservedby')");
    $disc = $mydb->executeQuery();
  }

  message("New [". $name ."] Booked successfully!", "success");
  //  unsetSessions();
    redirect("index.php?view=detail");
}

?>

<div class="container">
  <?php include'../sidebar.php';?>

    <div class="col-md-8">
      <!--<div class="jumbotron">-->
        <div class="">
          <div class="panel panel-default" style="margin-top:78px;">
            <div class="panel-body">  
             
                 <?php // include'navigator.php';?>


          <td valign="top" class="body" style="padding-bottom:10px;">
          <form action="index.php?view=payment" method="post"  name="personal" >

           <fieldset >
           <legend><h2>Billing Details</h2></legend>

           <p>

            <strong>FIRST NAME:</strong> <?php echo $name;?> <br/>
            <strong>LAST NAME:</strong> <?php echo $last;?><br/>
            <strong>COUNTRY:</strong> <?php echo $country;?><br/>
            <strong>CITY:</strong> <?php  echo $city;?><br/>
            <strong>ADDRESS:</strong> <?php echo $address;?><br/>
            <strong>ZIP CODE:</strong> <?php echo $zip; ?><br/>
            <strong>PHONE:</strong> <?php echo $phone;?><br/>
            <strong>E-MAIL:</strong> <?php echo $email;?><br/>
            <strong>GUEST TYPE:</strong> <?php echo $guesttype;?><br/>
            <strong>PAYMENT TYPE:</strong> <?php echo $paymenttype;?><br/>
            <strong>COMPANY NAME:</strong> <?php echo $company_name;?><br/>
          </p>

        <table class="table table-hover">
                  <thead>
              <tr  bgcolor="#999999">
              <th width="10">#</th>
              <th align="center" width="120">Room Type</th>
              <th align="center" width="120">Check In</th>
              <th align="center" width="120">Check Out</th>
              <th align="center" width="120">Nights</th>
              <th  width="120">Price</th>
              <th align="center" width="120">Room</th>
              <th align="center" width="90">Amount</th>
           
              
         
            </tr> 
          </thead>
          <tbody>
              
            <?php
            
    
              $mydb->setQuery("SELECT *,typeName FROM room ro, roomtype rt WHERE ro.typeID = rt.typeID and roomNo =". $_SESSION['roomid']);
              $cur = $mydb->loadResultList();

            foreach ($cur as $result) {
              echo '<tr>'; 
              echo '<td></td>';
              echo '<td>'. $result->typeName.'</td>';
              echo '<td>'.$arival.'</td>';
              echo '<td>'.$departure.'</td>';
              echo '<td>'.$days.'</td>';
              echo '<td >&#8358; '. $result->price.'</td>';
               echo '<td >1</td>';
                echo '<td >&#8358;'. $result->price.'</td>';
        

              
              echo '</tr>';
            } 
           $payable= $result->price *$days;
           $_SESSION['pay']= $payable;
            ?>
          </tbody>
          <tfoot>
           <tr>
                   <td colspan="5"></td><td align="right"><b>Order Total:  </b>
                   <td align="left" colspan="2">
                  <b> <?php echo '&#8358; '.$payable= $days*$result->price; ?></b>
                    <input type="hidden" name="totalfordiscount" id="totalfordiscount" value="<?php echo $payable= $days*$result->price;?>">
                  </td>
          </tr>
         <tr>
                  <!--  <td colspan="4"></td><td colspan="5">
                            <div class="col-xs-12 col-sm-12" align="right">
                                <button type="submit" class="btn btn-primary" align="right" name="btnlogin">Payout</button>
                            </div>
                   
                     </td> -->
                     <td colspan="4">
                      <div class="form-group">
                         <p><input type="checkbox" name="givediscount" id="givediscount" value="1"> Do you want to give discount</p>
                    </div>
                     </td>
                     <td  class="disct"><b>Percent Discount (%)</b> <input type="text" name="percent" id="percent" ></td>
                     <td  class="disct"><b>Total Discount</b> <input  type="text" name="total_discount" id="total_discount" ></td>
          </tr>
         
          </tfoot>  
        </table>
              <div class="form-group">
                  <div class="col-md-12">
 
                    <div class="col-md-10" style="border:1px solid silver;box-shadow: 2px 5px 2px 5px #846E86;">
                      <h3>Special Request</h3>

                      <p>Some request might have corresponding charges and subject to availability.</p>
                 <!-- <textarea class="form-control input-sm" name="message" placeholder="What's on your mind?">
                </textarea> -->
                
                  <!--the special request form-->
                    <div class="form-group">
                         <p><input type="checkbox" name="special_request" value="1" > Do you wish to add a special request</p>
                    </div>
                    <div class="form-group">
                      <label>Name:</label>
                      <input type="text" class="form-control" value="<?php  echo $name.' '.$last;?>" name="guestname">
                    </div>
                    <div class="form-group">
                      <label>Phone:</label>
                      <input type="text" class="form-control" value="<?php  echo $phone;?>" name="guestphone">
                    </div>
                    <div class="form-group">
                      <label>Booking For:</label>
                      <select class="form-control" name="guestbooking">
                        <option value="">--Select--</option>
                        <?php 
                        include_once('includes/dbconnect.php');
                        $query = mysqli_query($conn,"select * from amenities");
                        while($rows = mysqli_fetch_assoc($query)){
                          ?>
                          <option value="<?php echo $rows['amen_name']?>"><?php echo $rows['amen_name'];?></option>
                        <?php } ?>
                      </select>
                    </div>
                     <div class="form-group">
                      <label>Price:</label>
                       <input type="text" class="form-control" autocomplete="off" name="price">
                    </div>
                    <div class="form-group">
                      <label>purpose:</label>
                      <textarea style="width:100%; height:200px;" name="purpose"></textarea>
                    </div>
                    <div class="form-group">
                      <label>Checkin Date:</label>
                      <input type="text" class="form-control from" value="<?php echo $arival;?>" autocomplete="off" name="checkindate"  data-date="" data-date-format="yyyy-mm-dd" data-link-field="any" data-link-format="yyyy-mm-dd">
                    </div>
                    <div class="form-group">
                      <label>Checkout Date:</label>
                      <input type="text" class="form-control to" value="<?php echo $departure;?>" autocomplete="off" name="checkoutdate"  data-date="" data-date-format="yyyy-mm-dd" data-link-field="any" data-link-format="yyyy-mm-dd">
                    </div>
                    <div class="form-group">
                      <label>Time:</label>
                      <input type="text" class="form-control" autocomplete="off" name="timeofevent">
                    </div>
                     <div class="form-group">
                       <button type="submit" class="btn btn-primary" align="right" name="btnsubmitbooking">Submit Booking</button>
                  
                </div>
                    </div>
                  </div>
                </div>
                



              </form>

            </div>
          </div>  
          
        </div>
    <!--  </div>-->
    </div>
    <!--/span--> 
    <!--Sidebar-->

  </div>
  <!--/row-->



