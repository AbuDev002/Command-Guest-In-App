

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<fieldset>
										<legend><h2 class="text-left">Contact</h2></legend>
											
									<iframe width="500" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps/ms?msa=0&amp;msid=216284867372251359438.0004f12903dc23b39f7d5&amp;ie=UTF8&amp;t=h&amp;ll=9.991135,122.813008&amp;spn=0.00317,0.003219&amp;z=17&amp;output=embed"></iframe>
							</fieldset>		
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
