<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Resturant"){?>
	<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>
		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default" style="margin-top:78px;">
						<div class="panel-heading">
							<!-- <ol class="breadcrumb">
								<li><a href="index.php?page=managefood">List of Foods</a></li>
							    <li><a href="index.php?page=addfood">Add Food</a></li>
							</ol> -->
						</div>
							<div class="panel-body">	
								<div class="col-md-3"></div>
								<div class="col-md-6" style="border:1px solid silver;box-shadow: 2px 5px 2px 5px #846E86;">
									<?php
									$processedby = $_SESSION['account_name'];
									include_once('includes/dbconnect.php');
									if($_SERVER['REQUEST_METHOD'] =='POST'){
										
										$guestname = $_POST['guestname'];
										$foodname = $_POST['foodname'];
										$foodprice = $_POST['foodprice'];
										$guestname = mysqli_real_escape_string($conn,$guestname);
										$foodname = mysqli_real_escape_string($conn,$foodname);
										$foodprice = mysqli_real_escape_string($conn,$foodprice);
										if(empty($guestname) || empty($foodname) || empty($foodprice)){
											echo "<p class='alert alert-danger'>Please enter all fields!</p>";
										}else{

										//select sum of resturant
										$getresturantbalance_qr = mysqli_query($conn,'select sum(price) as restotalamnts from buyfood');
										          $resturantbalance_rs =  mysqli_fetch_array($getresturantbalance_qr);
										          $resturant_total = $resturantbalance_rs['restotalamnts'] + $foodprice;

											$buyfood_sql ="INSERT INTO buyfood (guestname,foodname,price,soldby)  VALUES('".$guestname."','".$foodname."','".$foodprice."','".$processedby."')";
											$buyfood_qry = mysqli_query($conn,$buyfood_sql);
											if($buyfood_qry){
												//update resturant account balance
											   $updateresturantbalance = mysqli_query($conn,"UPDATE tbl_units SET current_ubalance='$resturant_total' WHERE id=2");
												echo "<p class='alert alert-success'>Thank you for buying our food!</p>";
											}else{
												echo "<p class='alert alert-danger'>Unable to buy food!</p>";
											}
										}
									}
									?>
									<form action="" method="post">	
									<label>Name of Guest</label>
									<div class="form-group">
										<input type="text" class="form-control" name="guestname">
									</div>
									<label>Food Type</label>
									<div class="form-group">
									<select class="form-control" name="foodname">
										<option value="">--Select--</option>
										 <?php 
					                        include_once('includes/dbconnect.php');
					                        $query = mysqli_query($conn,"select * from foods");
					                        while($rows = mysqli_fetch_assoc($query)){
					                          ?>
					                          <option value="<?php echo $rows['foodname'];?>"><?php echo $rows['foodname'];?></option>
					                       <?php } ?>
									</select>
									
									</div>
									<label>Food Price</label>
									<div class="form-group">
										<input type="text" class="form-control" name="foodprice">
									</div>
									<label>Type of Guest</label>
									<div class="form-group">
										<select name="guesttype" class="form-control">
											<option>--Select--</option>
											<option value="indoor">Indoor Guest</option>
											<option value="outdoor">Outdoor Guest</option>
										</select>
									</div>
									<button type="submit" class="form-control">Buy Food</button>
									</form>
								</div>
								<div class="col-md-3"></div>
									
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>