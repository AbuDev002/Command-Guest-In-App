<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Reception"){?>
	<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default" style="margin-top:78px;">
				
							<div class="panel-body">
							<ol class="breadcrumb">
							  <li><a href="index.php?page=manageroom">List of Rooms</a></li>
							  <li><a href="index.php?page=checkincheckout">Book Room</a></li>
							  
							</ol>	
								<div class="col-xs-12 col-sm-12">
									<table class="table table-bordered guest_record">
										<thead>
										<tr>
											<th>Room Name</th>
											<th>Room Type</th>
											<th>Room Price</th>
											<th>No of Adult</th>
											<th>No of Children</th>
											<!-- <th>Room Status</th> -->
										</tr>
										</thead>
										<tbody>
										<?php
											$i =0; 
											include_once('includes/dbconnect.php');
											$roomlist = mysqli_query($conn,'select * from room');
											while($rlist = mysqli_fetch_array($roomlist)){
											$i++;
										  ?>
											<tr>
												<td><?php echo $rlist['roomName'];?></td>
												<td>
													<?php 
														$query =mysqli_query($conn,"select * from roomtype where typeID = ".$rlist['typeID']."");
														   $roomtype = mysqli_fetch_array($query);
														   echo $roomtype['typename'];
													?>		
												</td>
												<td>&#8358; <?php echo number_format($rlist['price'], 2, '.', ',');?></td>
												<td><?php echo $rlist['Adults'];?></td>
												<td><?php echo $rlist['Children'];?></td>
												<!-- <td><?php //echo $rlist['roomstatus'];?></td> -->
											</tr>
									   <?php } ?>
									   </tbody>
									</table>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>