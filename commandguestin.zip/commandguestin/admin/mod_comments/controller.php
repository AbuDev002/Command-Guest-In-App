<?php 
require_once("../../includes/dbconnect.php");
if(isset($_GET['did'])){
 $did = $_GET['did'];
		$sql = "DELETE FROM comments WHERE comment_id=".$did."";
		$result = mysqli_query($conn,$sql)or die('Could not delete record: ' . mysqli_error());
		header('location:index.php');
		//redirect('index.php');
}
?>