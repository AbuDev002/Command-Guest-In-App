<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Reception" || $_SESSION['account_type'] == "Accountant"  || $_SESSION['account_type'] == "Resturant"  || $_SESSION['account_type'] == "Chairman"){?>
	<!--End of Header-->
<?php
//error_reporting(1);
	
	$error = "";
	if(isset($_POST['chngP'])){
		$current_password =strip_tags($_POST['current_password']);
		$new_password =strip_tags($_POST['new_password']);
		$repassword =strip_tags($_POST['repassword']);
		if($current_password && $new_password && $repassword){
		if( $new_password == $repassword){
			$pass_hash = sha1($current_password);
				include_once('includes/dbconnect.php');
				$query =mysqli_query($conn,"SELECT * FROM useraccounts WHERE ACCOUNT_PASSWORD='".$pass_hash."'");
					if(mysqli_num_rows($query)> 0){
						//include('connection/connect.php');
						$sec_hash = sha1($new_password);
						$ses_id = $_SESSION['account_id'];
						//$id=$_SESSION['email'];
						//$lastupdated = time();
					$query2 =mysqli_query($conn,"UPDATE useraccounts SET ACCOUNT_PASSWORD='".$sec_hash."' WHERE ACCOUNT_ID =$ses_id");
					if($query2){
						$error ="<p class='alert alert-success'>Password Changed successfully!</p>";
					}
					}else{
						$error ="<p class='alert alert-danger'>Current Password Is Incorrect!</p>";
					}
				
		}else
			$error ="<p class='alert alert-danger'>Your password do not match!</p>";
	}else
			$error ="<p class='alert alert-danger'>Please enter your recovery detials!</p>";
	
	}
?>
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
				<div class="">
					
					<div class="panel panel-default" style="margin-top:78px;">
				
							<div class="panel-body">	
								<?php if(isset($error)){ echo $error;}?>
								<div class="col-xs-12 col-sm-12">
			<div class="panel panel-default" style="border:1px solid silver;box-shadow: 2px 5px 2px 5px #846E86;">
		   
			 <div class="panel-heading">Change Password</div>
			  <div class="panel-body">	
						   <form  method="POST" action="">
								<div class="col-xs-12 col-sm-12">

					            	<div class="form-group">
					            		<div class="row">
					            			<div class="col-xs-12 col-sm-12">
					            				<label class="control-label" for="to">Current Password</label>
						              			
								                  <input type="password" name="current_password" class="form-control" placeholder="Current Password...">
							                   
						              		</div>
						            	</div>
						            </div>
						            <div class="form-group">
						            	<div class="row">
					            			<div class="col-xs-12 col-sm-12">
					            				<label class="control-label" for="to">New Password</label>
						              			
								                  <input type="password" name="new_password" class="form-control" placeholder="New Password...">
								                   
						              		</div>
						            	</div>
						            </div>

						            <div class="form-group">
						            	<div class="row">
					            			<div class="col-xs-12 col-sm-12">
					            				<label class="control-label" for="to">Confirm-Password</label>
						              			
								                 <input type="password" name="repassword" class="form-control" placeholder="Confirm Password...">
								                   
						              		</div>
						            	</div>
						            </div>

						            <div class="form-group">
						            	<div class="row">
					            			<div class="col-xs-12 col-sm-12">
						           				 <button type="submit" class="btn btn-default" align="right" name="chngP">Change Password</button>
						           			 </div>
						            	</div>
						            </div>
						        </div>
					        </form>
						</div>
			
		</div>
		<!-- <--the result> -->

				


		<!-- the end of the result -->	
								</div>
							</div>
						</div>	
				
					
				</div>
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>