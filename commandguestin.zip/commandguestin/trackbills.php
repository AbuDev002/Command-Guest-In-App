<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Reception"){?>
	<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default" style="margin-top:78px;">
				
							<div class="panel-body">	
								<div class="row">
									<div class="col-md-3"></div>
									<div class="col-md-6" style="border:1px solid silver;box-shadow: 2px 5px 2px 5px #846E86;">
										<form action="" method="post">
											<div class="form-group">
												<label>Phone No.</label>
												<input type="text" placeholder="Enter guest phone no or email..." class="form-control" name="trackbills">
											</div>
											<div class="form-group">
												<button class="btn btn-default btn-block">Search Guest History</button>
											</div>
										</form>
									</div>
									<div class="col-md-3"></div>
									
								</div>
								<hr>
								
								<div class="container">
									<?php
										include_once('includes/dbconnect.php');
										if(isset($_POST['trackbills'])){
										$search = mysqli_real_escape_string($conn,$_POST['trackbills']);	
										$sql ="SELECT * FROM guest WHERE phone LIKE '%$search%' OR email LIKE '%$search%'";
										$post = mysqli_query($conn,$sql);
										if($post){
											while($result = mysqli_fetch_assoc($post)){
										
									?>
										<table class="table table-bordered table-responsive">
											<tr>
												<td><?php echo $result['firstname'].' '.$result['lastname'];?></td>
												<td><?php echo $result['phone'];?></td>
												<td><?php echo $result['email'];?></td>
												<td><a href="index.php?page=billlist&guestid=<?php echo $result['guest_id'];?>"><span class="glyphicon glyphicon-eye-open"></span>  History</a></td>
											</tr>
										</table>
											
									<?php } } }else{ ?>
										<center><p>Your Search Query Not Found.</p></center>
									<?php } ?>
								</div>	
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>