<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Reception"){?>
	<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default" style="margin-top:78px;">
						<div class="panel-body">
						<h3>Guest Transaction History</h3>	
							<?php 
								if(isset($_GET['guestid'])){
									include_once('includes/dbconnect.php');
									$guestid = $_GET['guestid'];
									$gethistory_sql ="SELECT * FROM reservation WHERE guest_id=".$guestid."";
									$gethistory_qry = mysqli_query($conn,$gethistory_sql);
									if($rs = mysqli_num_rows($gethistory_qry) == 1){
									while($gethistory_rs = mysqli_fetch_array($gethistory_qry)){
							?>
								 <table class="table table-bordered">
								 	<tr>
								 		<td><b>Room Name</b></td>
								 		<td><b>Guest Name:</b></td>
								 		<td><b>Date Arrived</b></td>
								 		<td><b>Date Departed</b></td>
								 		<td><b>Amount Payed</b></td>
								 		<td><b>Processed By</b></td>
								 	</tr>
								 	<tr>
								 		<td>
								 			<?php 
								 				$getroom =mysqli_query($conn,"select roomName from room where roomNo =".$gethistory_rs['roomNo']."");
								 				$room = mysqli_fetch_array($getroom);
								 				echo $room['roomName'];

								 			?>	
								 		</td>
								 		<td>
								 			<?php 
								 				$getguest =mysqli_query($conn,"select firstname,lastname from guest where guest_id =".$gethistory_rs['guest_id']."");
								 				$guest = mysqli_fetch_array($getguest);
								 				echo $guest['firstname'].' '.$guest['lastname'];

								 			?>
								 				
								 		</td>
								 		<td><?php echo $gethistory_rs['arrival'];?></td>
								 		<td><?php echo $gethistory_rs['arrival'];?></td>
								 		<td>&#8358; <?php echo number_format($gethistory_rs['payable'], 2, '.', ',');?></td>
								 		<?php //echo  money_format("&#8358;", $gethistory_rs['payable']);?>
								 		<td><?php echo $gethistory_rs['reservedby'];?></td>
								 	</tr>
								 </table>
							<?php 
								}
							}else{
									echo "<center><h4>No record found</h4></center>";
								}
							}
							?>
						</div>
					</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>