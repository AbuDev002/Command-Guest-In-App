<?php if(isset($_SESSION['account_type']) && $_SESSION['account_type'] == "Reception"){?>
	<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default" style="margin-top:78px;">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="panel panel-default">
												<div class="panel-heading">
													<ol class="breadcrumb">
														<li><a href="index.php?page=manageguest">List of Guest</a></li>
														  <!-- <li><a href="index.php?page=newguest">Add New Guest</a></li> -->
													</ol>
												</div>
												<div class="panel-body">
											<table class="table table-bordered table-reponsive guest_record">
												<thead>
												<tr>
													<th>#</th>
													<th>Guest Name</th>
													<th>Phone</th>
													<th>Email</th>
													<th>View History</th>
												</tr>
											</thead>
											<tbody>
												<?php
													$i =0; 
													include_once('includes/dbconnect.php');
													$guestlist = mysqli_query($conn,'select * from guest');
													while($glist = mysqli_fetch_array($guestlist)){
													$i++;
												?>
											
											<tr>
												<td><?php echo $i;?></td>
												<td><?php echo $glist['firstname']." ".$glist['firstname'];?></td>
												<td><?php echo $glist['phone'];?></td>
												<td><?php echo $glist['email'];?></td>
												<td><a href="index.php?page=billlist&guestid=<?php echo $glist['guest_id'];?>"><span class="glyphicon glyphicon-eye-open"></span></a></td>
											</tr>

											<?php } ?>
											</tbody>
											</table>
												</div>
											</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php }else{?>

<!--End of Header-->
<div class="container">
	<?php include'sidebar.php';?>

		<div class="col-md-8">
			<!--<div class="jumbotron">-->
				<div class="">
					<div class="panel panel-default">
				
							<div class="panel-body">	
								<div class="col-xs-12 col-sm-12">
									<div class="alert alert-warning">Sorry you are not authorize to access page</div>
								</div>
							</div>
						</div>	
				
					
				</div>
		<!--	</div>-->
		</div>
		<!--/span--> 
		<!--Sidebar-->

	</div>
	<!--/row-->
<?php } ?>