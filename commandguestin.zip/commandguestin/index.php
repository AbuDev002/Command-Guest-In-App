<?php
require_once("includes/initialize.php");
$content='home.php';
$view = (isset($_GET['page']) && $_GET['page'] != '') ? $_GET['page'] : '';
switch ($view) {
	case 'home' :
        $title="Home";	
		$content='home.php';		
		break;
	case 'gallery' :
	    $title="Gallery";	
		$content ='gallery.php';
		break;
	case 'resturant' :
	    $title="Resturant";	
		$content ='resturant.php';
		break;
	case 'pool' :
	    $title="Swimming Pool";	
		$content ='pool.php';
		break;
	case 'about' :
	    $title="About Us";	
		$content = 'about.php';		
		break;

	case 'contact' :
	    $title="Contacts";	
 		$content ='contact.php';		
		break;
				
     case 'rates' :
	    $title="Room and Rates";	
		$content='rates.php';
		break;	

	case 'location' :
	    $title="Location";	
		$content ='sitemap.php';
		break;
	//receptionist pages
	case 'manageguest' :
	    $title="Manage Guest";	
		$content ='manageguest.php';
		break;
	case 'newguest' :
	    $title="Add New Guest";	
		$content ='newguest.php';
		break;
	case 'managerooms' :
	    $title="Manage Rooms";	
		$content ='managerooms.php';
		break;
	case 'checkbalances' :
	    $title="Check Balances";	
		$content ='checkbalances.php';
		break;
	case 'trackbills' :
	    $title="Track Bills";	
		$content ='trackbills.php';
		break;
	case 'checkincheckout' :
	    $title="Check In Check Out";	
		$content ='checkincheckout.php';
		break;
	case 'hallsandpool' :
	    $title="Manage Halls and Pool";	
		$content ='hallsandpool.php';
		break;
	case 'makebooking' :
	    $title="Book Swimming Pool/Conference Hall";	
		$content ='makebooking.php';
		break;
	case 'smpoolbookinglist' :
	    $title="Swimming Pool Booking List";	
		$content ='smpoolbookinglist.php';
		break;
	case 'hallbookinglist' :
	    $title="Hall Booking List";	
		$content ='hallbookinglist.php';
		break;
	case 'billlist' :
	    $title="Bill History";	
		$content ='viewbills.php';
		break;
	case 'reservations' :
	    $title="Current Reservations";	
		$content ='currentreservations.php';
		break;
	case 'editreservation' :
	    $title="Edit Reservations";	
		$content ='editreservation.php';
		break;
	case 'checkout' :
	    $title="Check Out Reservation";	
		$content ='checkout.php';
		break;
	//accountant pages
	case 'cashtransaction' :
	    $title="Cash Withdrawal";	
		$content ='cashtransaction.php';
		break;
	case 'cashflow' :
	    $title="Cash Flow";	
		$content ='cashflow.php';
		break;
	case 'checkbalancesaccount' :
	    $title="Check Balances";	
		$content ='checkbalancesaccount.php';
		break;
	//Resturant pages
	case 'managefood' :
	    $title="Resturant Foods";	
		$content ='managefood.php';
		break;
	case 'addfood' :
	    $title="Add New Food";	
		$content ='addfood.php';
		break;
	case 'buyfood' :
	    $title="Buy Food";	
		$content ='buyfood.php';
		break;
	//Chairman Pages
	case 'unitsummary' :
	    $title="Summary of Units";	
		$content ='summaryofunits.php';
		break;
	//Change Password
	case 'changepassword' :
	    $title="Change Password";	
		$content ='change_password.php';
		break;		
	default :
	    $title="Home";	
		$content ='home.php';		
}

require_once 'theme/template.php';
?>
